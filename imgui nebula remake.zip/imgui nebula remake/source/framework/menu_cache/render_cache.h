#pragma once
#include "../settings/functions.h"
#include <unordered_map>
#include <string>

class RenderCache {
public:
    static RenderCache& get() {
        static RenderCache instance;
        return instance;
    }

    struct TextSizeCache {
        std::unordered_map<std::string, ImVec2> sizes;
        
        ImVec2 get_or_calculate(const std::string& text) {
            auto it = sizes.find(text);
            if (it != sizes.end()) {
                return it->second;
            }
            ImVec2 size = ImGui::CalcTextSize(text.c_str());
            sizes[text] = size;
            return size;
        }
        
        void clear() {
            sizes.clear();
        }
    };

    struct ColorCache {
        struct ColorKey {
            ImVec4 color;
            float alpha;
            
            bool operator==(const ColorKey& other) const {
                return color.x == other.color.x && color.y == other.color.y &&
                       color.z == other.color.z && color.w == other.color.w &&
                       alpha == other.alpha;
            }
        };
        
        struct ColorKeyHash {
            size_t operator()(const ColorKey& k) const {
                size_t h1 = std::hash<float>{}(k.color.x);
                size_t h2 = std::hash<float>{}(k.color.y);
                size_t h3 = std::hash<float>{}(k.color.z);
                size_t h4 = std::hash<float>{}(k.color.w);
                size_t h5 = std::hash<float>{}(k.alpha);
                return h1 ^ (h2 << 1) ^ (h3 << 2) ^ (h4 << 3) ^ (h5 << 4);
            }
        };
        
        std::unordered_map<ColorKey, ImU32, ColorKeyHash> colors;
        
        ImU32 get_or_calculate(const ImVec4& color, float alpha = 1.0f) {
            ColorKey key{color, alpha};
            auto it = colors.find(key);
            if (it != colors.end()) {
                return it->second;
            }
            ImU32 col = IM_COL32(
                (int)(color.x * 255.0f),
                (int)(color.y * 255.0f),
                (int)(color.z * 255.0f),
                (int)(color.w * 255.0f * alpha)
            );
            colors[key] = col;
            return col;
        }
        
        void clear() {
            colors.clear();
        }
    };

    struct WatermarkCache {
        float text_height = 0.0f;
        float segment_widths[11] = {0};
        bool initialized = false;
        
        void initialize() {
            if (initialized) return;
            
            text_height = ImGui::CalcTextSize("A").y;
            segment_widths[0] = ImGui::CalcTextSize("Andy Bot").x;
            segment_widths[1] = ImGui::CalcTextSize(" | Build: ").x;
            segment_widths[2] = ImGui::CalcTextSize("Private").x;
            segment_widths[3] = ImGui::CalcTextSize(" | FPS: ").x;
            segment_widths[4] = ImGui::CalcTextSize("000").x;
            segment_widths[5] = ImGui::CalcTextSize(" | CPU: ").x;
            segment_widths[6] = ImGui::CalcTextSize("00.0%").x;
            segment_widths[7] = ImGui::CalcTextSize(" | Uptime: ").x;
            segment_widths[8] = ImGui::CalcTextSize("00:00:00").x;
            segment_widths[9] = ImGui::CalcTextSize(" | Date: ").x;
            segment_widths[10] = ImGui::CalcTextSize("00/00/0000").x;
            
            initialized = true;
        }
        
        float get_total_width() const {
            float total = 0.0f;
            for (int i = 0; i < 11; i++) {
                total += segment_widths[i];
            }
            return total;
        }
    };

    struct KeybindsCache {
        float text_height = 0.0f;
        float title_text_height = 0.0f;
        float max_name_width = 0.0f;
        float max_mode_key_width = 0.0f;
        int keybind_count = 0;
        bool initialized = false;
        
        void initialize() {
            if (initialized) return;
            text_height = ImGui::CalcTextSize("A").y;
            title_text_height = ImGui::CalcTextSize("keybind(s)").y;
            initialized = true;
        }
        
        void invalidate_dimensions() {
            max_name_width = 0.0f;
            max_mode_key_width = 0.0f;
            keybind_count = 0;
        }
    };

    struct ElementCache {
        std::unordered_map<std::string, ImVec2> dimensions;
        
        ImVec2 get(const std::string& key) {
            auto it = dimensions.find(key);
            if (it != dimensions.end()) {
                return it->second;
            }
            return ImVec2(0, 0);
        }
        
        void set(const std::string& key, const ImVec2& value) {
            dimensions[key] = value;
        }
        
        bool has(const std::string& key) {
            return dimensions.find(key) != dimensions.end();
        }
        
        void clear() {
            dimensions.clear();
        }
    };

    struct AnimationCache {
        std::unordered_map<std::string, float> values;
        
        float get(const std::string& key, float default_val = 0.0f) {
            auto it = values.find(key);
            if (it != values.end()) {
                return it->second;
            }
            return default_val;
        }
        
        void set(const std::string& key, float value) {
            values[key] = value;
        }
        
        void clear() {
            values.clear();
        }
    };

    TextSizeCache text_size;
    ColorCache color;
    WatermarkCache watermark;
    KeybindsCache keybinds;
    ElementCache element;
    AnimationCache animation;

    void initialize() {
        watermark.initialize();
        keybinds.initialize();
    }

    void clear_all() {
        text_size.clear();
        color.clear();
        element.clear();
        animation.clear();
        watermark.initialized = false;
        keybinds.initialized = false;
    }

    void begin_frame() {
        
        if (!watermark.initialized) watermark.initialize();
        if (!keybinds.initialized) keybinds.initialize();
    }

private:
    RenderCache() = default;
    ~RenderCache() = default;
    RenderCache(const RenderCache&) = delete;
    RenderCache& operator=(const RenderCache&) = delete;
};

#define CACHE RenderCache::get()
#define CACHE_TEXT_SIZE(text) CACHE.text_size.get_or_calculate(text)
#define CACHE_COLOR(color, alpha) CACHE.color.get_or_calculate(color, alpha)
