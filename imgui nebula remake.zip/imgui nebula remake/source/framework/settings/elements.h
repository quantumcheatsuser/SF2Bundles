#pragma once
#include <string>
#include "imgui.h"

class c_elements
{
public:

	struct
	{
		
		ImVec2 window_padding{ 5, 5 };
		
		ImVec2 padding{ 6, 6 };
		
		ImVec2 spacing{ 4, 4 };
	} content;

	struct
	{
		ImVec2 checkbox_size{ 11, 11 };
		
		float slider_height{ 12 };
		
		float dropdown_height{ 18 };
		
		ImVec2 color_size{ 24, 11 };
		
		ImVec2 key_size{ 30, 14 };
		ImVec2 padding{ 6, 6 };
		
		ImVec2 spacing{ 4, 4 };
	} widgets;

	struct
	{
		ImVec2 size{ 30, 30 };
		
		float height{ 23 };
	} section;
};

inline c_elements* elements = new c_elements();