#pragma once
#include "imgui.h"
#include <string>
#include <vector>

class c_variables {
public:
  struct {
    ImGuiWindowFlags main_flags{
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav |
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoBackground |
        ImGuiWindowFlags_Tooltip};
    ImGuiWindowFlags flags{
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav |
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoBackground};
    ImVec2 padding{0, 0};

    ImVec2 spacing{5, 4};
    float shadow_size{100};
    float shadow_alpha{0.3f};
    float border_size{0};
    float rounding{
        0}; 
    float width{0};
    
    float titlebar{22};
    
    float scrollbar_size{2};
    bool hover_hightlight{true};
  } window;

  struct {
    float menu_alpha{0};
    bool menu_opened{true};
    bool menu_glow{false};
    int menu_key{45};
    bool tab_animation{true};
  } gui;

  struct {
    ImFont *tahoma;
  } font;
};

inline c_variables *var = new c_variables();