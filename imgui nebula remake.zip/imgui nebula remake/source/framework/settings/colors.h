#pragma once
#include "imgui.h"

class c_colors
{
public:
	
	ImColor accent{ 44, 108, 169 };

	struct
	{
		
		ImColor background_one{ 20, 20, 20 };
		
		ImColor background_two{ 30, 30, 30 };
		
		ImColor stroke{ 20, 20, 20 };
		
		ImColor inline_col{ 50, 50, 50 };
		
		ImColor gradient{ 35, 35, 35 };
	} window;

	struct
	{
		
		ImColor stroke_two{ 20, 20, 20 };
		
		ImColor text{ 239, 239, 239 };
		
		ImColor text_inactive{ 120, 120, 120 };
		
		ImColor tab_background{ 26, 26, 26 };
	} widgets;
};

inline c_colors* clr = new c_colors();