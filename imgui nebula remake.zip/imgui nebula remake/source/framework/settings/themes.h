#pragma once
#include "imgui.h"
#include <string>
#include <map>

struct theme_preset
{
    std::string name;
    ImColor stroke;
    ImColor inline_col;
    ImColor gradient;
    ImColor accent;
    ImColor background_one;
    ImColor background_two;
    ImColor text;
    ImColor text_inactive;
    ImColor tab_background;
};

inline std::map<std::string, theme_preset> themes = {};

inline void apply_theme(const std::string& theme_name)
{
    auto it = themes.find(theme_name);
    if (it == themes.end())
        return;

    const theme_preset& theme = it->second;

    extern class c_colors* clr;

    clr->window.stroke          = theme.stroke;
    clr->window.inline_col      = theme.inline_col;
    clr->window.gradient        = theme.gradient;
    clr->window.background_one  = theme.background_one;
    clr->window.background_two  = theme.background_two;
    clr->accent                 = theme.accent;
    clr->widgets.stroke_two     = theme.stroke;
    clr->widgets.text           = theme.text;
    clr->widgets.text_inactive  = theme.text_inactive;
    clr->widgets.tab_background = theme.tab_background;
}
