#include "../settings/functions.h"
#define _CRT_NO_SECURE_NO_WARNINGS
void c_gui::update_animations() {
  float t = (float)ImGui::GetTime();
  for (auto &ctx : m_anim_colors) {
    ImGuiID ce_id = ctx.ce_id;
    int anim_mode = m_color_storage.GetInt(
        ce_id + 1, 0); 
    if (anim_mode == 0)
      continue;

    int anim_speed_pct = m_color_storage.GetInt(ce_id + 20, 100);
    float *col = ctx.col;

    float pri[4] = {m_color_storage.GetFloat(ce_id + 3, col[0]),
                    m_color_storage.GetFloat(ce_id + 4, col[1]),
                    m_color_storage.GetFloat(ce_id + 5, col[2]),
                    m_color_storage.GetFloat(ce_id + 6, col[3])};
    float sec[4] = {m_color_storage.GetFloat(ce_id + 7, 1.0f),
                    m_color_storage.GetFloat(ce_id + 8, 1.0f),
                    m_color_storage.GetFloat(ce_id + 9, 1.0f),
                    m_color_storage.GetFloat(ce_id + 10, 1.0f)};

    float speed_factor = (anim_speed_pct / 100.0f) * 2.0f;

    if (anim_mode == 1) 
    {
      float h, s, v;
      ColorConvertRGBtoHSV(col[0], col[1], col[2], h, s, v);
      h = ImFmod(t * speed_factor * 0.2f, 1.0f);
      ColorConvertHSVtoRGB(h, ImMax(s, 0.5f), ImMax(v, 0.5f), col[0], col[1],
                           col[2]);
    } else if (anim_mode == 2) 
    {
      float factor = (sinf(t * speed_factor) + 1.0f) * 0.5f;
      for (int n = 0; n < 4; n++)
        col[n] = ImLerp(pri[n], sec[n], factor);
    } else if (anim_mode == 3) 
    {
      bool on = ImFmod(t, 2.0f / (speed_factor + 0.1f)) >
                (1.0f / (speed_factor + 0.1f));
      for (int n = 0; n < 4; n++)
        col[n] = on ? pri[n] : sec[n];
    }
  }
}

static void color_edit_restore_h(const float *col, float *H) {
  ImGuiContext &g = *GImGui;
  IM_ASSERT(g.ColorEditCurrentID != 0);
  if (g.ColorEditSavedID != g.ColorEditCurrentID ||
      g.ColorEditSavedColor !=
          ImGui::ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0)))
    return;
  *H = g.ColorEditSavedHue;
}

static void color_edit_restore_hs(const float *col, float *H, float *S,
                                  float *V) {
  ImGuiContext &g = *GImGui;
  IM_ASSERT(g.ColorEditCurrentID != 0);
  if (g.ColorEditSavedID != g.ColorEditCurrentID ||
      g.ColorEditSavedColor !=
          ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0)))
    return;

  if (*S == 0.0f || (*H == 0.0f && g.ColorEditSavedHue == 1))
    *H = g.ColorEditSavedHue;

  if (*V == 0.0f)
    *S = g.ColorEditSavedSat;
}

bool color_button(const char *desc_id, const ImVec4 &col) {
  ImGuiWindow *window = GetCurrentWindow();
  if (window->SkipItems)
    return false;

  const ImGuiID id = window->GetID(desc_id);

  const ImRect rect(window->DC.CursorPos,
                    window->DC.CursorPos + elements->widgets.color_size);
  ItemSize(rect, 0.0f);
  if (!ItemAdd(rect, id))
    return false;

  bool hovered, held;
  bool pressed = ButtonBehavior(rect, id, &hovered, &held);

  RenderColorRectWithAlphaCheckerboard(
      window->DrawList, rect.Min + ImVec2(2, 2), rect.Max - ImVec2(2, 2),
      draw->get_clr(col, 0.f), 5, ImVec2(0, 0));
  draw->fade_rect_filled(
      window->DrawList, rect.Min + ImVec2(2, 2), rect.Max - ImVec2(2, 2),
      draw->get_clr(col),
      draw->get_clr({col.x - 0.2f, col.y - 0.2f, col.z - 0.2f, col.w}),
      fade_direction::vertically);
  draw->rect(window->DrawList, rect.Min, rect.Max,
             draw->get_clr(var->window.hover_hightlight && hovered
                               ? clr->accent
                               : clr->widgets.stroke_two));
  draw->rect(window->DrawList, rect.Min + ImVec2(1, 1), rect.Max - ImVec2(1, 1),
             draw->get_clr(clr->window.stroke));
  return pressed;
}

bool color_picker(const char *label, float col[4], ImGuiColorEditFlags flags,
                  const float * ) {
  ImGuiContext &g = *GImGui;
  ImGuiWindow *window = GetCurrentWindow();
  if (window->SkipItems)
    return false;

  ImDrawList *draw_list = window->DrawList;
  ImGuiStyle &style = g.Style;
  ImGuiIO &io = g.IO;

  (void)CalcItemWidth(); 
  const bool is_readonly = ((g.NextItemData.ItemFlags | g.CurrentItemFlags) &
                            ImGuiItemFlags_ReadOnly) != 0;
  g.NextItemData.ClearFlags();

  PushID(label);
  const bool set_current_color_edit_id = (g.ColorEditCurrentID == 0);
  if (set_current_color_edit_id)
    g.ColorEditCurrentID = window->IDStack.back();
  BeginGroup();

  if (!(flags & ImGuiColorEditFlags_NoSidePreview))
    flags |= ImGuiColorEditFlags_NoSmallPreview;

  if (!(flags & ImGuiColorEditFlags_NoOptions))
    ColorPickerOptionsPopup(col, flags);

  if (!(flags & ImGuiColorEditFlags_PickerMask_))
    flags |= ((g.ColorEditOptions & ImGuiColorEditFlags_PickerMask_)
                  ? g.ColorEditOptions
                  : ImGuiColorEditFlags_DefaultOptions_) &
             ImGuiColorEditFlags_PickerMask_;
  if (!(flags & ImGuiColorEditFlags_InputMask_))
    flags |= ((g.ColorEditOptions & ImGuiColorEditFlags_InputMask_)
                  ? g.ColorEditOptions
                  : ImGuiColorEditFlags_DefaultOptions_) &
             ImGuiColorEditFlags_InputMask_;
  IM_ASSERT(ImIsPowerOfTwo(
      flags &
      ImGuiColorEditFlags_PickerMask_)); 
  IM_ASSERT(ImIsPowerOfTwo(
      flags & ImGuiColorEditFlags_InputMask_)); 
  if (!(flags & ImGuiColorEditFlags_NoOptions))
    flags |= (g.ColorEditOptions & ImGuiColorEditFlags_AlphaBar);

  int components = (flags & ImGuiColorEditFlags_NoAlpha) ? 3 : 4;
  bool alpha_bar = (flags & ImGuiColorEditFlags_AlphaBar) &&
                   !(flags & ImGuiColorEditFlags_NoAlpha);
  ImVec2 picker_pos = window->DC.CursorPos;
  float bars_width = 13;
  float sv_picker_size = 120;
  float bar_height = 161;
  float bar0_pos_x = picker_pos.x + sv_picker_size + 4;
  float bar1_pos_x = bar0_pos_x + bars_width + 4;

  float backup_initial_col[4];
  memcpy(backup_initial_col, col, components * sizeof(float));

  float wheel_thickness = sv_picker_size * 0.08f;
  float wheel_r_outer = sv_picker_size * 0.50f;
  float wheel_r_inner = wheel_r_outer - wheel_thickness;
  ImVec2 wheel_center(picker_pos.x + (sv_picker_size + bars_width) * 0.5f,
                      picker_pos.y + sv_picker_size * 0.5f);

  float triangle_r = wheel_r_inner - (int)(sv_picker_size * 0.027f);
  ImVec2 triangle_pa = ImVec2(triangle_r, 0.0f); 
  ImVec2 triangle_pb =
      ImVec2(triangle_r * -0.5f, triangle_r * -0.866025f); 
  ImVec2 triangle_pc =
      ImVec2(triangle_r * -0.5f, triangle_r * +0.866025f); 

  float H = col[0], S = col[1], V = col[2];
  float R = col[0], G = col[1], B = col[2];
  if (flags & ImGuiColorEditFlags_InputRGB) {

    ColorConvertRGBtoHSV(R, G, B, H, S, V);
    color_edit_restore_hs(col, &H, &S, &V);
  } else if (flags & ImGuiColorEditFlags_InputHSV) {
    ColorConvertHSVtoRGB(H, S, V, R, G, B);
  }

  bool value_changed = false, value_changed_h = false, value_changed_sv = false;

  InvisibleButton("sv", ImVec2(sv_picker_size, sv_picker_size));
  if (IsItemActive() && !is_readonly) {
    S = ImSaturate((io.MousePos.x - picker_pos.x) / (sv_picker_size - 1));
    V = 1.0f -
        ImSaturate((io.MousePos.y - picker_pos.y) / (sv_picker_size - 1));
    color_edit_restore_h(
        col, &H); 
                  
    value_changed = value_changed_sv = true;
  }

  SetCursorScreenPos(ImVec2(bar0_pos_x, picker_pos.y));
  InvisibleButton("hue", ImVec2(bars_width, bar_height));
  if (IsItemActive() && !is_readonly) {
    H = ImSaturate((io.MousePos.y - picker_pos.y) / (bar_height - 1));
    value_changed = value_changed_h = true;
  }

  if (alpha_bar) {
    SetCursorScreenPos(ImVec2(bar1_pos_x, picker_pos.y));
    InvisibleButton("alpha", ImVec2(bars_width, bar_height));
    if (IsItemActive()) {
      col[3] = 1.0f - ImSaturate((io.MousePos.y - picker_pos.y) /
                                 (bar_height - 1));
      value_changed = true;
    }
  }

  if (value_changed_h || value_changed_sv) {
    if (flags & ImGuiColorEditFlags_InputRGB) {
      ColorConvertHSVtoRGB(H, S, V, col[0], col[1], col[2]);
      g.ColorEditSavedHue = H;
      g.ColorEditSavedSat = S;
      g.ColorEditSavedID = g.ColorEditCurrentID;
      g.ColorEditSavedColor =
          ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0));
    } else if (flags & ImGuiColorEditFlags_InputHSV) {
      col[0] = H;
      col[1] = S;
      col[2] = V;
    }
  }

  bool value_changed_fix_hue_wrap = false;

  if (value_changed_fix_hue_wrap && (flags & ImGuiColorEditFlags_InputRGB)) {
    float new_H, new_S, new_V;
    ColorConvertRGBtoHSV(col[0], col[1], col[2], new_H, new_S, new_V);
    if (new_H <= 0 && H > 0) {
      if (new_V <= 0 && V != new_V)
        ColorConvertHSVtoRGB(H, S, new_V <= 0 ? V * 0.5f : new_V, col[0],
                             col[1], col[2]);
      else if (new_S <= 0)
        ColorConvertHSVtoRGB(H, new_S <= 0 ? S * 0.5f : new_S, new_V, col[0],
                             col[1], col[2]);
    }
  }

  if (value_changed) {
    if (flags & ImGuiColorEditFlags_InputRGB) {
      R = col[0];
      G = col[1];
      B = col[2];
      ColorConvertRGBtoHSV(R, G, B, H, S, V);
      color_edit_restore_hs(
          col, &H, &S,
          &V); 
    } else if (flags & ImGuiColorEditFlags_InputHSV) {
      H = col[0];
      S = col[1];
      V = col[2];
      ColorConvertHSVtoRGB(H, S, V, R, G, B);
    }
  }

  const int style_alpha8 = IM_F32_TO_INT8_SAT(style.Alpha);
  const ImU32 col_black = IM_COL32(0, 0, 0, style_alpha8);
  const ImU32 col_white = IM_COL32(255, 255, 255, style_alpha8);
  const ImU32 col_midgrey = IM_COL32(128, 128, 128, style_alpha8);
  const ImU32 col_hues[6 + 1] = {
      IM_COL32(255, 0, 0, style_alpha8), IM_COL32(255, 255, 0, style_alpha8),
      IM_COL32(0, 255, 0, style_alpha8), IM_COL32(0, 255, 255, style_alpha8),
      IM_COL32(0, 0, 255, style_alpha8), IM_COL32(255, 0, 255, style_alpha8),
      IM_COL32(255, 0, 0, style_alpha8)};

  ImVec4 hue_color_f(1, 1, 1, style.Alpha);
  ColorConvertHSVtoRGB(H, 1, 1, hue_color_f.x, hue_color_f.y, hue_color_f.z);
  ImU32 hue_color32 = ColorConvertFloat4ToU32(hue_color_f);
  ImU32 user_col32_striped_of_alpha = ColorConvertFloat4ToU32(
      ImVec4(R, G, B, style.Alpha)); 

  ImVec2 sv_cursor_pos;

  draw_list->AddRectFilledMultiColor(
      picker_pos, picker_pos + ImVec2(sv_picker_size, sv_picker_size),
      col_white, hue_color32, hue_color32, col_white);
  draw_list->AddRectFilledMultiColor(
      picker_pos, picker_pos + ImVec2(sv_picker_size, sv_picker_size), 0, 0,
      col_black, col_black);
  RenderFrameBorder(picker_pos,
                    picker_pos + ImVec2(sv_picker_size, sv_picker_size), 0.0f);
  sv_cursor_pos.x = ImClamp(
      IM_ROUND(picker_pos.x + ImSaturate(S) * sv_picker_size), picker_pos.x + 2,
      picker_pos.x + sv_picker_size -
          2); 
  sv_cursor_pos.y =
      ImClamp(IM_ROUND(picker_pos.y + ImSaturate(1 - V) * sv_picker_size),
              picker_pos.y + 2, picker_pos.y + sv_picker_size - 2);

  for (int i = 0; i < 6; ++i)
    draw_list->AddRectFilledMultiColor(
        ImVec2(bar0_pos_x, picker_pos.y + i * (bar_height / 6)),
        ImVec2(bar0_pos_x + bars_width,
               picker_pos.y + (i + 1) * (bar_height / 6)),
        col_hues[i], col_hues[i], col_hues[i + 1], col_hues[i + 1]);
  float bar0_line_y = IM_ROUND(picker_pos.y + H * (bar_height - 10));
  RenderFrameBorder(
      ImVec2(bar0_pos_x, picker_pos.y),
      ImVec2(bar0_pos_x + bars_width, picker_pos.y + bar_height), 0.0f);

  draw->rect(window->DrawList, ImVec2(bar0_pos_x - 1, bar0_line_y),
             ImVec2(bar0_pos_x + bars_width + 1, bar0_line_y + 10),
             draw->get_clr(clr->widgets.text), 0, 0, 1);

  draw_list->AddCircleFilled(sv_cursor_pos, 4, user_col32_striped_of_alpha, 30);
  draw_list->AddCircle(sv_cursor_pos, 4 + 1, col_midgrey, 30);
  draw_list->AddCircle(sv_cursor_pos, 4, col_white, 30);

  if (alpha_bar) {
    float alpha = ImSaturate(col[3]);
    ImRect bar1_bb(bar1_pos_x, picker_pos.y, bar1_pos_x + bars_width,
                   picker_pos.y + bar_height);
    draw_list->AddRectFilledMultiColor(
        bar1_bb.Min, bar1_bb.Max, user_col32_striped_of_alpha,
        user_col32_striped_of_alpha, col_black, col_black);
    float bar1_line_y =
        IM_ROUND(picker_pos.y + (1.0f - alpha) * (bar_height - 10));
    RenderFrameBorder(bar1_bb.Min, bar1_bb.Max, 0.0f);
    draw->rect(window->DrawList, ImVec2(bar1_pos_x - 1, bar1_line_y),
               ImVec2(bar1_pos_x + bars_width + 1, bar1_line_y + 10),
               draw->get_clr(clr->widgets.text), 0, 0, 1);
  }

  EndGroup();

  if (value_changed &&
      memcmp(backup_initial_col, col, components * sizeof(float)) == 0)
    value_changed = false;
  if (value_changed &&
      g.LastItemData.ID != 0) 
                              
    MarkItemEdited(g.LastItemData.ID);

  if (set_current_color_edit_id)
    g.ColorEditCurrentID = 0;
  PopID();

  return value_changed;
}

bool c_gui::color_edit(std::string_view label, float col[4], bool active_alpha,
                       bool color_only) {
  ImGuiWindow *window = GetCurrentWindow();
  if (window->SkipItems)
    return false;

  ImGuiContext &g = *GImGui;
  const ImGuiStyle &style = g.Style;
  const float square_sz = GetFrameHeight();
  (void)FindRenderedTextEnd(label.data()); 
  float w_full = CalcItemWidth();
  g.NextItemData.ClearFlags();
  ImGuiColorEditFlags flags = 0;

  BeginGroup();
  PushID(label.data());

  ImGuiStorage *storage = &gui->m_color_storage;
  ImGuiID ce_id = ImHashStr(label.data());

  int anim_mode =
      storage->GetInt(ce_id + 1, 0); 
  int anim_speed_pct = storage->GetInt(ce_id + 20, 100);

  float pri[4] = {storage->GetFloat(ce_id + 3, col[0]),
                  storage->GetFloat(ce_id + 4, col[1]),
                  storage->GetFloat(ce_id + 5, col[2]),
                  storage->GetFloat(ce_id + 6, col[3])};
  float sec[4] = {
      storage->GetFloat(ce_id + 7, 1.0f), storage->GetFloat(ce_id + 8, 1.0f),
      storage->GetFloat(ce_id + 9, 1.0f), storage->GetFloat(ce_id + 10, 1.0f)};

  if (!color_only) {
    bool found = false;
    for (auto &ctx : gui->m_anim_colors) {
      if (ctx.col == col) {
        found = true;
        ctx.ce_id = ce_id;
        break;
      }
    }
    if (!found) {
      gui->m_anim_colors.push_back({col, ce_id});
    }
  }

  const bool set_current_color_edit_id = (g.ColorEditCurrentID == 0);
  if (set_current_color_edit_id)
    g.ColorEditCurrentID = window->IDStack.back();

  const ImGuiColorEditFlags flags_untouched = 0;
  if (flags & ImGuiColorEditFlags_NoInputs)
    flags = (flags & (~ImGuiColorEditFlags_DisplayMask_)) |
            ImGuiColorEditFlags_DisplayRGB | ImGuiColorEditFlags_NoOptions;

  if (!(flags & ImGuiColorEditFlags_NoOptions))
    ColorEditOptionsPopup(col, flags);

  if (!(flags & ImGuiColorEditFlags_DisplayMask_))
    flags |= (g.ColorEditOptions & ImGuiColorEditFlags_DisplayMask_);
  if (!(flags & ImGuiColorEditFlags_DataTypeMask_))
    flags |= (g.ColorEditOptions & ImGuiColorEditFlags_DataTypeMask_);
  if (!(flags & ImGuiColorEditFlags_PickerMask_))
    flags |= (g.ColorEditOptions & ImGuiColorEditFlags_PickerMask_);
  if (!(flags & ImGuiColorEditFlags_InputMask_))
    flags |= (g.ColorEditOptions & ImGuiColorEditFlags_InputMask_);
  flags |=
      (g.ColorEditOptions &
       ~(ImGuiColorEditFlags_DisplayMask_ | ImGuiColorEditFlags_DataTypeMask_ |
         ImGuiColorEditFlags_PickerMask_ | ImGuiColorEditFlags_InputMask_));
  IM_ASSERT(ImIsPowerOfTwo(
      flags &
      ImGuiColorEditFlags_DisplayMask_)); 
  IM_ASSERT(ImIsPowerOfTwo(
      flags & ImGuiColorEditFlags_InputMask_)); 

  const bool alpha = (flags & ImGuiColorEditFlags_NoAlpha) == 0;
  (void)(flags & ImGuiColorEditFlags_HDR); 
  const float w_button = (flags & ImGuiColorEditFlags_NoSmallPreview)
                             ? 0.0f
                             : (square_sz + style.ItemInnerSpacing.x);
  const float w_inputs = ImMax(w_full - w_button, 1.0f);
  w_full = w_inputs + w_button;

  float f[4] = {col[0], col[1], col[2], alpha ? col[3] : 1.0f};
  if ((flags & ImGuiColorEditFlags_InputHSV) &&
      (flags & ImGuiColorEditFlags_DisplayRGB))
    ColorConvertHSVtoRGB(f[0], f[1], f[2], f[0], f[1], f[2]);
  else if ((flags & ImGuiColorEditFlags_InputRGB) &&
           (flags & ImGuiColorEditFlags_DisplayHSV)) {

    ColorConvertRGBtoHSV(f[0], f[1], f[2], f[0], f[1], f[2]);
    color_edit_restore_hs(col, &f[0], &f[1], &f[2]);
  }
  int i[4] = {IM_F32_TO_INT8_UNBOUND(f[0]), IM_F32_TO_INT8_UNBOUND(f[1]),
              IM_F32_TO_INT8_UNBOUND(f[2]), IM_F32_TO_INT8_UNBOUND(f[3])};

  bool value_changed = false;
  bool value_changed_as_float = false;

  const ImVec2 pos = window->DC.CursorPos;
  const float inputs_offset_x =
      (style.ColorButtonPosition == ImGuiDir_Left) ? w_button : 0.0f;
  window->DC.CursorPos.x = pos.x + inputs_offset_x;

  ImGuiWindow *picker_active_window = NULL;

  gui->push_style_var(ImGuiStyleVar_PopupBorderSize, 1.f);
  gui->push_style_color(ImGuiCol_Border, draw->get_clr(clr->window.stroke));
  gui->push_style_color(ImGuiCol_PopupBg,
                        draw->get_clr(clr->window.background_one));
  if (!(flags & ImGuiColorEditFlags_NoSmallPreview)) {
    (void)(((flags & ImGuiColorEditFlags_NoInputs) ||
                                   (style.ColorButtonPosition == ImGuiDir_Left))
                                      ? 0.0f
                                      : w_inputs + style.ItemInnerSpacing.x); 

    const ImVec4 col_v4(col[0], col[1], col[2], alpha ? col[3] : 1.0f);
    if (color_button("##ColorButton", col_v4)) {
      if (!(flags & ImGuiColorEditFlags_NoPicker)) {
        
        g.ColorPickerRef = col_v4;
        OpenPopup("picker");
        SetNextWindowPos(g.LastItemData.Rect.GetBL() +
                         ImVec2(0.0f, style.ItemSpacing.y));
      }
    }

    int active_picker_tab_cached = storage->GetInt(ce_id, 0);
    int anim_mode_cached = storage->GetInt(ce_id + 1, 0);
    float anim_h = 110.f;
    if (active_picker_tab_cached == 1 && (anim_mode_cached == 2 || anim_mode_cached == 3))
        anim_h = 145.f;
    SetNextWindowSize(ImVec2(170.f, active_picker_tab_cached == 1 ? anim_h : 200.f), ImGuiCond_Always);
    gui->push_style_var(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    if (BeginPopup("picker")) {
      if (g.CurrentWindow->BeginCount == 1) {
        picker_active_window = g.CurrentWindow;

        int active_picker_tab =
            storage->GetInt(ce_id, 0); 

        const float kTabBarH = 23.f;
        const float kPad = elements->content.padding.x;

        ImDrawList *dl = GetWindowDrawList();
        ImDrawList *bg_dl = GetBackgroundDrawList();
        ImVec2 popup_pos = GetWindowPos();
        ImVec2 popup_sz = GetWindowSize();

        // Draw outline shadow
        draw->rect(bg_dl, popup_pos - ImVec2(1, 1),
                   popup_pos + popup_sz + ImVec2(1, 1),
                   draw->get_clr({0, 0, 0, 0.5f}));

        // Draw main background
        draw->rect_filled(dl, popup_pos, popup_pos + popup_sz,
                          draw->get_clr(clr->window.stroke));

        // Draw content area background
        draw->rect_filled(dl, popup_pos + ImVec2(1, kTabBarH),
                          popup_pos + ImVec2(popup_sz.x - 1, popup_sz.y - 1),
                          draw->get_clr(clr->window.background_two));

        // Draw tab bar background
        draw->fade_rect_filled(dl, popup_pos + ImVec2(1, 1),
                               popup_pos + ImVec2(popup_sz.x - 1, kTabBarH - 1),
                               draw->get_clr(clr->window.gradient),
                               draw->get_clr(clr->window.background_two),
                               fade_direction::vertically);

        // Draw accent line at top
        draw->rect_filled(dl, popup_pos + ImVec2(1, 1),
                          popup_pos + ImVec2(popup_sz.x - 1, 3),
                          draw->get_clr(clr->accent));

        // Draw separator below accent
        draw->rect_filled(dl, popup_pos + ImVec2(1, 3),
                          popup_pos + ImVec2(popup_sz.x - 1, 4),
                          draw->get_clr(clr->window.stroke));

        // Draw separator below tabs
        draw->rect_filled(dl, popup_pos + ImVec2(1, kTabBarH - 1),
                          popup_pos + ImVec2(popup_sz.x - 1, kTabBarH),
                          draw->get_clr(clr->window.stroke));

        const int tab_count = color_only ? 1 : 2;
        const char *tab_labels[2] = {"Color", "Animation"};

        float tab_x = popup_pos.x + 1.f;

        for (int i = 0; i < tab_count; ++i) {
          float tw = CalcTextSize(tab_labels[i]).x + 12.f;
          ImVec2 tab_min = ImVec2(tab_x, popup_pos.y + 4.f);
          ImVec2 tab_max = tab_min + ImVec2(tw, kTabBarH - 5.f);

          bool tab_hovered, tab_held;
          ImGuiID tab_btn_id = GetID(tab_labels[i]);
          ImRect tab_rect(tab_min, tab_max);
          ItemSize(tab_rect);
          ItemAdd(tab_rect, tab_btn_id);
          bool tab_pressed = ButtonBehavior(tab_rect, tab_btn_id, &tab_hovered, &tab_held);

          if (tab_pressed)
            active_picker_tab = i;

          bool is_active = (active_picker_tab == i);

          if (is_active)
            draw->fade_rect_filled(dl, tab_min, tab_max,
                                   draw->get_clr(clr->window.inline_col),
                                   draw->get_clr(clr->window.gradient),
                                   fade_direction::vertically);
          else
            draw->rect_filled(dl, tab_min, tab_max,
                              draw->get_clr(clr->widgets.tab_background));

          ImVec2 text_pos = tab_min + ImVec2((tw - CalcTextSize(tab_labels[i]).x) * 0.5f,
                                             ((kTabBarH - 5.f) - var->font.tahoma->FontSize) * 0.5f);
          draw->text_outline(dl, var->font.tahoma, var->font.tahoma->FontSize,
                             text_pos, draw->get_clr(clr->widgets.text), tab_labels[i]);

          if (i < tab_count - 1)
            draw->rect_filled(dl, ImVec2(tab_max.x, tab_min.y),
                              ImVec2(tab_max.x + 1, tab_max.y),
                              draw->get_clr(clr->window.stroke));

          tab_x += tw + 1.f;
        }

        const float content_x   = popup_pos.x + kPad;
        const float content_y   = popup_pos.y + kTabBarH + kPad;
        const float content_w   = popup_sz.x - kPad * 2.f;

        SetCursorScreenPos(ImVec2(content_x, content_y));

        if (active_picker_tab == 0) {
          ImGuiColorEditFlags picker_flags_to_forward =
              ImGuiColorEditFlags_DataTypeMask_ |
              ImGuiColorEditFlags_PickerMask_ | ImGuiColorEditFlags_InputMask_ |
              ImGuiColorEditFlags_HDR | ImGuiColorEditFlags_NoAlpha |
              ImGuiColorEditFlags_AlphaBar;
          ImGuiColorEditFlags picker_flags =
              (flags_untouched & picker_flags_to_forward) |
              ImGuiColorEditFlags_DisplayMask_ | ImGuiColorEditFlags_NoLabel |
              ImGuiColorEditFlags_AlphaPreviewHalf;

          if (color_picker(
                  "##picker", col,
                  picker_flags | (active_alpha ? ImGuiColorEditFlags_AlphaBar : 0),
                  &g.ColorPickerRef.x)) {
            value_changed = true;
            if (anim_mode == 0)
              for (int n = 0; n < 4; n++) pri[n] = col[n];
          }

          int ri = (int)(col[0] * 255.f + 0.5f);
          int gi = (int)(col[1] * 255.f + 0.5f);
          int bi = (int)(col[2] * 255.f + 0.5f);
          int ai = (int)(col[3] * 255.f + 0.5f);

          char rgb_buf[64];
          ImFormatString(rgb_buf, IM_ARRAYSIZE(rgb_buf), "%d, %d, %d, %d", ri, gi, bi, ai);

          SetCursorScreenPos(ImVec2(content_x, content_y + 120.f + 3.f));
          PushItemWidth(120.f);
          if (gui->text_field("##rgb_input", rgb_buf, IM_ARRAYSIZE(rgb_buf), NULL,
                              ImGuiInputTextFlags_EnterReturnsTrue)) {
            int r = ri, g = gi, b = bi, a = ai;
            if (sscanf(rgb_buf, "%d, %d, %d, %d", &r, &g, &b, &a) >= 3 ||
                sscanf(rgb_buf, "%d %d %d %d", &r, &g, &b, &a) >= 3) {
              col[0] = ImSaturate(r / 255.0f); col[1] = ImSaturate(g / 255.0f);
              col[2] = ImSaturate(b / 255.0f); col[3] = ImSaturate(a / 255.0f);
              value_changed = true;
              if (anim_mode == 0) for (int n = 0; n < 4; n++) pri[n] = col[n];
            }
          }

          char hex_buf[16];
          ImFormatString(hex_buf, IM_ARRAYSIZE(hex_buf), "#%02X%02X%02X%02X", ri, gi, bi, ai);

          SetCursorScreenPos(ImVec2(content_x, content_y + 120.f + 3.f + 18.f + 2.f));
          if (gui->text_field("##hex_input", hex_buf, IM_ARRAYSIZE(hex_buf), NULL,
                              ImGuiInputTextFlags_EnterReturnsTrue)) {
            const char *s = hex_buf;
            if (s[0] == '#') s++;
            unsigned int hex_val = 0;
            if (sscanf(s, "%x", &hex_val) == 1) {
              if (strlen(s) <= 6) {
                col[0] = ((hex_val >> 16) & 0xFF) / 255.0f;
                col[1] = ((hex_val >> 8)  & 0xFF) / 255.0f;
                col[2] = (hex_val & 0xFF)          / 255.0f;
                col[3] = 1.0f;
              } else {
                col[0] = ((hex_val >> 24) & 0xFF) / 255.0f;
                col[1] = ((hex_val >> 16) & 0xFF) / 255.0f;
                col[2] = ((hex_val >> 8)  & 0xFF) / 255.0f;
                col[3] = (hex_val & 0xFF)          / 255.0f;
              }
              value_changed = true;
              if (anim_mode == 0) for (int n = 0; n < 4; n++) pri[n] = col[n];
            }
          }
          PopItemWidth();
        } else {
          gui->push_style_var(ImGuiStyleVar_ItemSpacing, elements->widgets.spacing);

          draw->text_outline(dl, var->font.tahoma, var->font.tahoma->FontSize,
                             ImVec2(content_x, content_y),
                             draw->get_clr(clr->widgets.text), "Animation");

          SetCursorScreenPos(ImVec2(content_x, content_y + var->font.tahoma->FontSize + 4.f));

          const char *anim_items[] = {"None", "Rainbow", "Fading", "Flashing"};
          gui->dropdown("anim_mode_dd", &anim_mode, anim_items, IM_ARRAYSIZE(anim_items), true);

          int anim_spd_i = anim_speed_pct;
          if (gui->slider_int("Speed", &anim_spd_i, 1, 100, false, "%d%%"))
            anim_speed_pct = anim_spd_i;

          if (anim_mode == 2 || anim_mode == 3) {
            gui->label_color_edit("Primary",   pri, active_alpha, true);
            gui->label_color_edit("Secondary", sec, active_alpha, true);
          }

          gui->pop_style_var();
        }

        storage->SetInt(ce_id, active_picker_tab);
        storage->SetInt(ce_id + 1, anim_mode);
        storage->SetInt(ce_id + 20, anim_speed_pct);
        for (int n = 0; n < 4; n++) {
          storage->SetFloat(ce_id + 3 + n, pri[n]);
          storage->SetFloat(ce_id + 7 + n, sec[n]);
        }
      }
      EndPopup();
    }
    gui->pop_style_var(); 
  }
  gui->pop_style_var();
  gui->pop_style_color(2);

  if (value_changed && picker_active_window == NULL) {
    if (!value_changed_as_float)
      for (int n = 0; n < 4; n++)
        f[n] = i[n] / 255.0f;
    if ((flags & ImGuiColorEditFlags_DisplayHSV) &&
        (flags & ImGuiColorEditFlags_InputRGB)) {
      g.ColorEditSavedHue = f[0];
      g.ColorEditSavedSat = f[1];
      ColorConvertHSVtoRGB(f[0], f[1], f[2], f[0], f[1], f[2]);
      g.ColorEditSavedID = g.ColorEditCurrentID;
      g.ColorEditSavedColor =
          ColorConvertFloat4ToU32(ImVec4(f[0], f[1], f[2], 0));
    }
    if ((flags & ImGuiColorEditFlags_DisplayRGB) &&
        (flags & ImGuiColorEditFlags_InputHSV))
      ColorConvertRGBtoHSV(f[0], f[1], f[2], f[0], f[1], f[2]);

    col[0] = f[0];
    col[1] = f[1];
    col[2] = f[2];
    if (alpha)
      col[3] = f[3];
  }

  if (set_current_color_edit_id)
    g.ColorEditCurrentID = 0;
  PopID();
  EndGroup();

  if (picker_active_window && g.ActiveId != 0 &&
      g.ActiveIdWindow == picker_active_window)
    g.LastItemData.ID = g.ActiveId;

  if (value_changed &&
      g.LastItemData.ID != 0) 
                              
    MarkItemEdited(g.LastItemData.ID);

  return value_changed;
}

bool c_gui::label_color_edit(std::string_view label, float col[4],
                             bool active_alpha, bool color_only) {
  draw->text_outline(GetWindowDrawList(), var->font.tahoma,
                     var->font.tahoma->FontSize,
                     GetCursorScreenPos() + ImVec2(1, 0),
                     draw->get_clr(clr->widgets.text), label.data());
  gui->set_cursor_pos(ImVec2(GetWindowWidth() - elements->widgets.color_size.x -
                                 GetStyle().WindowPadding.x,
                             GetCursorPos().y));
  gui->color_edit(label, col, active_alpha, color_only);

  return true;
}
