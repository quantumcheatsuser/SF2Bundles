﻿#include "../settings/functions.h"

bool begin_child_ex(const char* name, ImGuiID id, int x, int,
    const ImVec2& size_arg, ImGuiChildFlags child_flags,
    ImGuiWindowFlags window_flags) {
    ImGuiContext& g = *GImGui;
    ImGuiWindow* parent_window = g.CurrentWindow;
    IM_ASSERT(id != 0);

    const ImGuiChildFlags ImGuiChildFlags_SupportedMask_ =
        ImGuiChildFlags_Border | ImGuiChildFlags_AlwaysUseWindowPadding |
        ImGuiChildFlags_ResizeX | ImGuiChildFlags_ResizeY |
        ImGuiChildFlags_AutoResizeX | ImGuiChildFlags_AutoResizeY |
        ImGuiChildFlags_AlwaysAutoResize | ImGuiChildFlags_FrameStyle;
    IM_UNUSED(ImGuiChildFlags_SupportedMask_);
    IM_ASSERT((child_flags & ~ImGuiChildFlags_SupportedMask_) == 0 &&
        "Illegal ImGuiChildFlags value. Did you pass ImGuiWindowFlags "
        "values instead of ImGuiChildFlags?");
    IM_ASSERT((window_flags & ImGuiWindowFlags_AlwaysAutoResize) == 0 &&
        "Cannot specify ImGuiWindowFlags_AlwaysAutoResize for "
        "BeginChild(). Use ImGuiChildFlags_AlwaysAutoResize!");
    if (child_flags & ImGuiChildFlags_AlwaysAutoResize) {
        IM_ASSERT((child_flags &
            (ImGuiChildFlags_ResizeX | ImGuiChildFlags_ResizeY)) == 0 &&
            "Cannot use ImGuiChildFlags_ResizeX or ImGuiChildFlags_ResizeY "
            "with ImGuiChildFlags_AlwaysAutoResize!");
        IM_ASSERT(
            (child_flags &
                (ImGuiChildFlags_AutoResizeX | ImGuiChildFlags_AutoResizeY)) != 0 &&
            "Must use ImGuiChildFlags_AutoResizeX or ImGuiChildFlags_AutoResizeY "
            "with ImGuiChildFlags_AlwaysAutoResize!");
    }
#ifndef IMGUI_DISABLE_OBSOLETE_FUNCTIONS
    if (window_flags & ImGuiWindowFlags_AlwaysUseWindowPadding)
        child_flags |= ImGuiChildFlags_AlwaysUseWindowPadding;
#endif
    if (child_flags & ImGuiChildFlags_AutoResizeX)
        child_flags &= ~ImGuiChildFlags_ResizeX;
    if (child_flags & ImGuiChildFlags_AutoResizeY)
        child_flags &= ~ImGuiChildFlags_ResizeY;

    window_flags |= ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_NoTitleBar;
    window_flags |= (parent_window->Flags &
        ImGuiWindowFlags_NoMove);
    if (child_flags & (ImGuiChildFlags_AutoResizeX | ImGuiChildFlags_AutoResizeY |
        ImGuiChildFlags_AlwaysAutoResize))
        window_flags |= ImGuiWindowFlags_AlwaysAutoResize;
    if ((child_flags & (ImGuiChildFlags_ResizeX | ImGuiChildFlags_ResizeY)) == 0)
        window_flags |=
        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings;

    if (child_flags & ImGuiChildFlags_FrameStyle) {
        PushStyleColor(ImGuiCol_ChildBg, g.Style.Colors[ImGuiCol_FrameBg]);
        PushStyleVar(ImGuiStyleVar_ChildRounding, g.Style.FrameRounding);
        PushStyleVar(ImGuiStyleVar_ChildBorderSize, g.Style.FrameBorderSize);
        PushStyleVar(ImGuiStyleVar_WindowPadding, g.Style.FramePadding);
        child_flags |=
            ImGuiChildFlags_Border | ImGuiChildFlags_AlwaysUseWindowPadding;
        window_flags |= ImGuiWindowFlags_NoMove;
    }

    g.NextWindowData.Flags |= ImGuiNextWindowDataFlags_HasChildFlags;
    g.NextWindowData.ChildFlags = child_flags;

    const char* temp_window_name;
    if (name)
        ImFormatStringToTempBuffer(&temp_window_name, NULL, "%s/%s_%08X",
            parent_window->Name, name, id);
    else
        ImFormatStringToTempBuffer(&temp_window_name, NULL, "%s/%08X",
            parent_window->Name, id);

    ImVec2 size = size_arg;
    if (size.x <= 0)
        size.x = (GetWindowWidth() - elements->content.padding.x * 2.f -
            elements->content.spacing.x * (x - 1)) /
        x;

    if (size.y <= 0) {
        child_flags |= ImGuiChildFlags_AutoResizeY;
        window_flags |= ImGuiWindowFlags_AlwaysAutoResize;

        ImGuiWindow* child_cache = FindWindowByName(temp_window_name);
        if (child_cache)
            size.y = child_cache->Size.y + var->window.titlebar +
            1.f;
        else
            size.y = 80.f;

        gui->set_next_window_size(
            ImVec2(size.x, 0.0f));
    }
    else {
        gui->set_next_window_size(size - ImVec2(0, var->window.titlebar));
    }

    gui->set_next_window_pos(parent_window->DC.CursorPos +
        ImVec2(0, var->window.titlebar));

    draw->rect_filled(parent_window->DrawList, parent_window->DC.CursorPos,
        parent_window->DC.CursorPos + size,
        draw->get_clr(clr->window.background_one));

    draw->rect_filled(parent_window->DrawList,
        parent_window->DC.CursorPos + ImVec2(1, 4),
        parent_window->DC.CursorPos + size - ImVec2(1, 1),
        draw->get_clr(clr->window.gradient));

    {
        ImVec2 strip_min = parent_window->DC.CursorPos + ImVec2(2, 5);
        ImVec2 strip_max = strip_min + ImVec2(size.x - 4, 16);
        draw->fade_rect_filled(parent_window->DrawList, strip_min, strip_max,
            draw->get_clr(clr->window.inline_col),
            draw->get_clr(clr->window.gradient),
            fade_direction::vertically);
    }

    draw->rect_filled(parent_window->DrawList,
        parent_window->DC.CursorPos + ImVec2(1, 1),
        parent_window->DC.CursorPos + ImVec2(size.x - 1, 3),
        draw->get_clr(clr->accent));

    draw->rect_filled(parent_window->DrawList,
        parent_window->DC.CursorPos + ImVec2(0, 3),
        parent_window->DC.CursorPos + ImVec2(size.x, 4),
        draw->get_clr(clr->window.stroke));

    draw->text_outline(parent_window->DrawList, var->font.tahoma,
        var->font.tahoma->FontSize,
        parent_window->DC.CursorPos + ImVec2(6, 6),
        draw->get_clr(clr->widgets.text), name);

    const float backup_border_size = g.Style.ChildBorderSize;
    if ((child_flags & ImGuiChildFlags_Border) == 0)
        g.Style.ChildBorderSize = 0.0f;

    const bool ret = gui->begin(temp_window_name, NULL, window_flags);

    g.Style.ChildBorderSize = backup_border_size;
    if (child_flags & ImGuiChildFlags_FrameStyle) {
        PopStyleVar(3);
        PopStyleColor();
    }

    ImGuiWindow* child_window = g.CurrentWindow;
    child_window->ChildId = id;

    if (child_window->BeginCount == 1)
        parent_window->DC.CursorPos = child_window->Pos;

    const ImGuiID temp_id_for_activation = ImHashStr("##Child", 0, id);
    if (g.ActiveId == temp_id_for_activation)
        ClearActiveID();
    if (g.NavActivateId == id &&
        !(window_flags & ImGuiWindowFlags_NavFlattened) &&
        (child_window->DC.NavLayersActiveMask != 0 ||
            child_window->DC.NavWindowHasScrollY)) {
        FocusWindow(child_window);
        NavInitWindow(child_window, false);
        SetActiveID(temp_id_for_activation, child_window);
        g.ActiveIdSource = g.NavInputSource;
    }
    return ret;
}

void c_gui::begin_child(std::string_view name, int x, int y,
    const ImVec2& size) {
    ImGuiID id = GetCurrentWindow()->GetID(name.data());

    gui->push_style_var(ImGuiStyleVar_WindowPadding, elements->widgets.padding);
    begin_child_ex(name.data(), id, x, y, size, ImGuiChildFlags_None,
        ImGuiWindowFlags_AlwaysUseWindowPadding |
        ImGuiWindowFlags_NoMove);
    gui->push_style_var(ImGuiStyleVar_ItemSpacing, elements->widgets.spacing);
}

void c_gui::end_child() {
    ImGuiContext& g = *GImGui;
    ImGuiWindow* child_window = g.CurrentWindow;

    IM_ASSERT(g.WithinEndChild == false);
    IM_ASSERT(
        child_window->Flags &
        ImGuiWindowFlags_ChildWindow);

    gui->pop_style_var();

    g.WithinEndChild = true;
    ImVec2 child_size = child_window->Size;
    gui->end();
    if (child_window->BeginCount == 1) {
        ImGuiWindow* parent_window = g.CurrentWindow;
        ImRect bb(parent_window->DC.CursorPos,
            parent_window->DC.CursorPos + child_size);
        ItemSize(child_size);
        if ((child_window->DC.NavLayersActiveMask != 0 ||
            child_window->DC.NavWindowHasScrollY) &&
            !(child_window->Flags & ImGuiWindowFlags_NavFlattened)) {
            ItemAdd(bb, child_window->ChildId);
            RenderNavHighlight(bb, child_window->ChildId);

            if (child_window->DC.NavLayersActiveMask == 0 &&
                child_window == g.NavWindow)
                RenderNavHighlight(ImRect(bb.Min - ImVec2(2, 2), bb.Max + ImVec2(2, 2)),
                    g.NavId, ImGuiNavHighlightFlags_Compact);
        }
        else {
            ItemAdd(bb, 0);

            if (child_window->Flags & ImGuiWindowFlags_NavFlattened)
                parent_window->DC.NavLayersActiveMaskNext |=
                child_window->DC.NavLayersActiveMaskNext;
        }
        if (g.HoveredWindow == child_window)
            g.LastItemData.StatusFlags |= ImGuiItemStatusFlags_HoveredWindow;
    }
    gui->pop_style_var();
    g.WithinEndChild = false;
    g.LogLinePosY = -FLT_MAX;
}

static constexpr float kTabBarH = 23.f;

bool c_gui::begin_multi_section(std::string_view name, int& active_tab,
    const char* const* tabs, int tab_count, int x,
    int, const ImVec2& size) {
    ImGuiContext& g = *GImGui;
    ImGuiWindow* parent_window = g.CurrentWindow;

    ImVec2 sz = size;
    if (sz.x <= 0)
        sz.x = (GetWindowWidth() - elements->content.padding.x * 2.f -
            elements->content.spacing.x * (x - 1)) /
        x;

    const float content_y_offset = 24.f;
    char child_name[256];
    ImFormatString(child_name, IM_ARRAYSIZE(child_name), "%s/##multi_%s",
        parent_window->Name, name.data());

    ImGuiWindowFlags multi_win_flags =
        ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_NoMove;

    if (sz.y <= 0) {
        ImGuiWindow* child_cache = FindWindowByName(child_name);
        if (child_cache)
            sz.y = child_cache->Size.y + content_y_offset +
            1.f;
        else
            sz.y = 80.f;

        g.NextWindowData.Flags |= ImGuiNextWindowDataFlags_HasChildFlags;
        g.NextWindowData.ChildFlags |=
            ImGuiChildFlags_AlwaysUseWindowPadding | ImGuiChildFlags_AutoResizeY;
        multi_win_flags |= ImGuiWindowFlags_AlwaysAutoResize;

        gui->set_next_window_size(
            ImVec2(sz.x - 2.f, 0.0f));
    }
    else {
        g.NextWindowData.Flags |= ImGuiNextWindowDataFlags_HasChildFlags;
        g.NextWindowData.ChildFlags |= ImGuiChildFlags_AlwaysUseWindowPadding;

        gui->set_next_window_size(
            ImVec2(sz.x - 2.f, sz.y - content_y_offset -
                1.f));
    }

    const ImVec2 origin = parent_window->DC.CursorPos;

    draw->rect_filled(parent_window->DrawList, origin, origin + sz,
        draw->get_clr(clr->window.stroke));

    draw->rect_filled(parent_window->DrawList, origin + ImVec2(1, 24),
        origin + sz - ImVec2(1, 1),
        draw->get_clr(clr->window.gradient));

    draw->fade_rect_filled(
        parent_window->DrawList, origin + ImVec2(1, 1),
        origin + ImVec2(sz.x - 1, 24), draw->get_clr(clr->window.gradient),
        draw->get_clr(clr->window.background_two), fade_direction::vertically);

    draw->rect_filled(parent_window->DrawList, origin + ImVec2(1, 1),
        origin + ImVec2(sz.x - 1, 3), draw->get_clr(clr->accent));

    draw->rect_filled(parent_window->DrawList, origin + ImVec2(1, 3),
        origin + ImVec2(sz.x - 1, 4),
        draw->get_clr(clr->window.stroke));

    SetCursorScreenPos(origin + ImVec2(1, 4));

    float active_tab_x_min = -1.f;
    float active_tab_x_max = -1.f;
    float tab_cursor_x = origin.x + 1.f;
    for (int i = 0; i < tab_count; ++i) {
        PushFont(var->font.tahoma);
        float tw = CalcTextSize(tabs[i]).x + 5.f + 6.f;
        PopFont();
        if (i == active_tab) { active_tab_x_min = tab_cursor_x - 1.f; active_tab_x_max = tab_cursor_x + tw + 1.f; }
        tab_cursor_x += tw - 1.f;
    }

    if (active_tab_x_min > 0.f)
    {
        if (active_tab_x_min > origin.x + 1.f)
            draw->rect_filled(parent_window->DrawList,
                ImVec2(origin.x + 1.f, origin.y + 23),
                ImVec2(active_tab_x_min, origin.y + 24),
                draw->get_clr(clr->window.stroke));
        
        if (active_tab_x_max < origin.x + sz.x - 1.f)
            draw->rect_filled(parent_window->DrawList,
                ImVec2(active_tab_x_max, origin.y + 23),
                ImVec2(origin.x + sz.x - 1.f, origin.y + 24),
                draw->get_clr(clr->window.stroke));
    }
    else
    {
        draw->rect_filled(parent_window->DrawList, origin + ImVec2(1, 23),
            origin + ImVec2(sz.x - 1, 24),
            draw->get_clr(clr->window.stroke));
    }

    for (int i = 0; i < tab_count; ++i) {

        ImGui::SetCursorScreenPos(
            ImVec2(parent_window->DC.CursorPos.x, origin.y + 4.f));
        sub_section(tabs[i], i, active_tab, (float)tab_count);
    }

    gui->set_next_window_pos(origin + ImVec2(1, content_y_offset));

    gui->push_style_var(ImGuiStyleVar_WindowPadding, elements->widgets.padding);
    gui->push_style_var(ImGuiStyleVar_ChildBorderSize, 0.0f);
    gui->push_style_color(ImGuiCol_ChildBg, IM_COL32(0, 0, 0, 0));

    const bool ret = gui->begin(child_name, nullptr, multi_win_flags);
    gui->push_style_var(ImGuiStyleVar_ItemSpacing, elements->widgets.spacing);

    return ret;
}

void c_gui::end_multi_section() {
    ImGuiContext& g = *GImGui;
    ImGuiWindow* child_window = g.CurrentWindow;
    ImGuiWindow* parent_window = g.CurrentWindow->ParentWindow;

    gui->pop_style_var();

    g.WithinEndChild = true;
    ImVec2 child_size = child_window->Size;
    gui->end();

    gui->pop_style_var();
    gui->pop_style_color();

    const ImVec2 full_sz(child_size.x + 2.f, child_size.y + 25.f);

    const ImRect bb(parent_window->DC.CursorPos,
        parent_window->DC.CursorPos + full_sz);
    ItemSize(full_sz);
    ItemAdd(bb, 0);

    gui->pop_style_var();

    g.WithinEndChild = false;
}
