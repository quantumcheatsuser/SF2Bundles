#include "../settings/functions.h"

bool c_gui::checkbox(std::string_view label, bool *callback) {
  ImGuiWindow *window = GetCurrentWindow();
  if (window->SkipItems)
    return false;

  ImGuiContext &g = *GImGui;
  const ImGuiStyle &style = g.Style;
  const ImGuiID id = window->GetID(label.data());

  const ImVec2 pos = window->DC.CursorPos;
  const float width = GetContentRegionAvail().x;
  const ImRect rect(pos,
                    pos + ImVec2(width, elements->widgets.checkbox_size.y));
  const ImRect clickable(rect.Min, rect.Min + elements->widgets.checkbox_size);
  const ImRect text(
      clickable.Min,
      clickable.Max +
          ImVec2(elements->widgets.padding.x +
                     var->font.tahoma
                         ->CalcTextSizeA(var->font.tahoma->FontSize, FLT_MAX,
                                         -1.f, label.data())
                         .x,
                 0));

  ItemSize(rect, style.FramePadding.y);
  if (!ItemAdd(rect, id))
    return false;

  bool hovered, held;
  bool pressed = ButtonBehavior(text, id, &hovered, &held);
  if (pressed)
    *callback = !(*callback);

  std::string anim_id = std::string("checkbox_") + label.data();
  float check_alpha = gui->animate_float(anim_id.c_str(), *callback ? 1.0f : 0.0f, 0.2f);

  ImU32 border_color = (var->window.hover_hightlight && hovered) ? draw->get_clr(clr->accent) : draw->get_clr(clr->window.stroke);
  draw->rect_filled(window->DrawList, clickable.Min, clickable.Max, border_color);

  draw->rect_filled(
      window->DrawList, clickable.Min + ImVec2(1, 1),
      clickable.Max - ImVec2(1, 1), draw->get_clr(clr->window.inline_col));

  if (check_alpha > 0.01f) {
    ImVec4 accent_dark = { clr->accent.Value.x * 0.6f, clr->accent.Value.y * 0.6f, clr->accent.Value.z * 0.6f, clr->accent.Value.w };
    draw->fade_rect_filled(
        window->DrawList, clickable.Min + ImVec2(1, 1),
        clickable.Max - ImVec2(1, 1),
        draw->get_clr(clr->accent, check_alpha),
        draw->get_clr(accent_dark, check_alpha),
        vertically);
  }

  ImVec2 text_min =
      ImVec2(clickable.Max.x + elements->widgets.padding.x, rect.Min.y - 4.f);
  ImVec2 text_max = ImVec2(rect.Max.x, rect.Max.y + 4.f);

  draw->text_clipped_outline(window->DrawList, var->font.tahoma, text_min,
                             text_max, draw->get_clr(clr->widgets.text),
                             label.data(), NULL, NULL, ImVec2(0.f, 0.5f));

  return pressed;
}

bool c_gui::checkbox(std::string_view label, bool *callback, int *key,
                     int *mode) {
  float y_pos = GetCursorPosY();
  gui->checkbox(label, callback);

  ImVec2 stored_pos = GetCursorPos();

  set_cursor_pos(ImVec2(GetWindowWidth() - elements->widgets.key_size.x -
                            GetStyle().WindowPadding.x,
                        y_pos));
  gui->keybind((std::stringstream{} << label << "key").str().c_str(), key,
               mode);

  set_cursor_pos(stored_pos); 
  return true;
}

bool c_gui::begin_folding_checkbox(std::string_view label, bool *value) {
  ImGuiWindow *window = GetCurrentWindow();
  if (window->SkipItems)
    return false;

  ImGuiContext &g = *GImGui;
  const ImGuiStyle &style = g.Style;
  const ImGuiID id = window->GetID(label.data());

  const ImVec2 pos = window->DC.CursorPos;
  const float width = GetContentRegionAvail().x;
  const ImRect rect(pos,
                    pos + ImVec2(width, elements->widgets.checkbox_size.y));
  const ImRect clickable(rect.Min, rect.Min + elements->widgets.checkbox_size);
  const ImRect text_rect(
      clickable.Min,
      clickable.Max +
          ImVec2(elements->widgets.padding.x +
                     var->font.tahoma
                         ->CalcTextSizeA(var->font.tahoma->FontSize, FLT_MAX,
                                         -1.f, label.data())
                         .x,
                 0));

  const ImRect header_clickable(rect.Min, rect.Max);

  ItemSize(rect, style.FramePadding.y);
  if (!ItemAdd(rect, id))
    return false;

  bool hovered, held;
  bool pressed = ButtonBehavior(text_rect, id, &hovered, &held);
  if (pressed)
    *value = !(*value);

  std::string anim_id = std::string("folding_") + label.data();
  float check_alpha = gui->animate_float(anim_id.c_str(), *value ? 1.0f : 0.0f, 0.2f);

  ImU32 border_color = (var->window.hover_hightlight && hovered) ? draw->get_clr(clr->accent) : draw->get_clr(clr->window.stroke);
  draw->rect_filled(window->DrawList, clickable.Min, clickable.Max, border_color);

  draw->rect_filled(
      window->DrawList, clickable.Min + ImVec2(1, 1),
      clickable.Max - ImVec2(1, 1), draw->get_clr(clr->window.inline_col));

  if (check_alpha > 0.01f) {
    ImVec4 accent_dark = { clr->accent.Value.x * 0.6f, clr->accent.Value.y * 0.6f, clr->accent.Value.z * 0.6f, clr->accent.Value.w };
    draw->fade_rect_filled(
        window->DrawList, clickable.Min + ImVec2(1, 1),
        clickable.Max - ImVec2(1, 1),
        draw->get_clr(clr->accent, check_alpha),
        draw->get_clr(accent_dark, check_alpha),
        vertically);
  }

  ImVec2 text_min =
      ImVec2(clickable.Max.x + elements->widgets.padding.x, rect.Min.y - 4.f);
  ImVec2 text_max = ImVec2(rect.Max.x, rect.Max.y + 4.f);
  draw->text_clipped_outline(window->DrawList, var->font.tahoma, text_min,
                             text_max, draw->get_clr(clr->widgets.text),
                             label.data(), NULL, NULL, ImVec2(0.f, 0.5f));

  if (*value) {
    m_folding_stack.push_back(ImVec2(clickable.Min.x, rect.Max.y));
    ImGui::Indent(10.f);
  }

  return *value;
}

bool c_gui::begin_folding_checkbox(std::string_view label, bool *value, int *key, int *mode) {
  float y_pos = GetCursorPosY();
  bool result = gui->begin_folding_checkbox(label, value);

  ImVec2 stored_pos = GetCursorPos();

  SetCursorPos(ImVec2(GetWindowWidth() - elements->widgets.key_size.x -
                            GetStyle().WindowPadding.x,
                        y_pos));
  gui->keybind((std::stringstream{} << label << "key").str().c_str(), key,
               mode);

  SetCursorPos(stored_pos); 
  
  return result;
}

void c_gui::end_folding_checkbox() {
    ImGuiWindow* window = GetCurrentWindow();

    if (!m_folding_stack.empty()) {
        ImVec2 start_pos = m_folding_stack.back();
        m_folding_stack.pop_back();

        ImGui::Unindent(10.f);

        float x_pos = start_pos.x + 5.5f;
        ImVec2 p1(x_pos - 1.f, start_pos.y + 6.f);
        ImVec2 p2(x_pos + 1.f, window->DC.CursorPos.y - 4.f);

        float fade_end_y = p1.y + 20.f;
        ImU32 col_transparent = IM_COL32(20, 20, 20, 0);
        ImU32 col_full        = IM_COL32(20, 20, 20, 255);

        if (fade_end_y < p2.y)
        {
            draw->fade_rect_filled(window->DrawList,
                p1, ImVec2(p2.x, fade_end_y),
                col_transparent, col_full,
                fade_direction::vertically);
            draw->rect_filled(window->DrawList,
                ImVec2(p1.x, fade_end_y), p2,
                col_full);
        }
        else
        {
            draw->fade_rect_filled(window->DrawList,
                p1, p2,
                col_transparent, col_full,
                fade_direction::vertically);
        }
    }
}
