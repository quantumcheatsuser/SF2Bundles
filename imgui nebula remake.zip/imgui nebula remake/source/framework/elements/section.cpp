﻿#include "../settings/functions.h"

bool c_gui::section(std::string_view icon, bool* callback)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID((std::stringstream{} << icon << "section").str().c_str());

    const ImVec2 pos = window->DC.CursorPos;
    const ImRect rect(pos, pos + elements->section.size);
    ItemSize(rect, style.FramePadding.y);
    if (!ItemAdd(rect, id))
        return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(rect, id, &hovered, &held);

    if (pressed)
        *callback = !*callback;

    draw->rect_filled(window->DrawList, rect.Min, rect.Max, draw->get_clr(clr->window.background_one));
    draw->rect_filled(window->DrawList, rect.Min + ImVec2(1, 1), rect.Max - ImVec2(1, 1), draw->get_clr(clr->window.gradient));

    if (hovered || *callback)
    {
        draw->rect_filled(window->DrawList,
            rect.Min + ImVec2(1, 1),
            ImVec2(rect.Max.x - 1, rect.Min.y + 2),
            draw->get_clr(clr->accent));
    }

    gui->sameline();

    return pressed;
}

bool c_gui::sub_section(std::string_view label, int section_id, int& section_variable, float /*count*/)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    (void)g.Style;
    const ImGuiID id = window->GetID(label.data());
    const bool selected = section_id == section_variable;

    PushFont(var->font.tahoma);
    const float text_w = CalcTextSize(label.data()).x;
    PopFont();

    const float padding_left = 5.f;
    const float padding_right = 6.f;
    const float tab_w = text_w + padding_left + padding_right;
    const float tab_h = 19.f;

    const ImVec2 pos = window->DC.CursorPos;
    const ImRect rect(pos, pos + ImVec2(tab_w, tab_h));

    ItemSize(rect, 0.f);
    if (!ItemAdd(rect, id))
        return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(rect, id, &hovered, &held);

    if (pressed)
        section_variable = section_id;

    std::string anim_id = std::string("tab_") + label.data();
    float fill_alpha = gui->animate_float((anim_id + "_fill").c_str(), selected ? 1.0f : 0.0f, 0.25f);
    float bg_alpha = gui->animate_float((anim_id + "_bg").c_str(), selected ? 0.0f : 1.0f, 0.25f);

    if (selected || fill_alpha > 0.01f)
    {
        float gradient_alpha = 1.0f - bg_alpha;
        draw->fade_rect_filled(window->DrawList,
            rect.Min, rect.Max,
            draw->get_clr(clr->window.inline_col, gradient_alpha),
            draw->get_clr(clr->window.gradient, gradient_alpha),
            vertically);
    }

    if (bg_alpha > 0.01f)
    {
        draw->rect_filled(window->DrawList,
            rect.Min, rect.Max,
            draw->get_clr(clr->widgets.tab_background, bg_alpha));
    }

    if (!selected)
    {
        window->DrawList->AddRect(
            rect.Min - ImVec2(1.f, 1.f),
            rect.Max + ImVec2(1.f, 1.f),
            draw->get_clr(clr->window.stroke));
    }
    else
    {
        ImU32 stroke_color = draw->get_clr(clr->window.stroke);
        window->DrawList->AddLine(
            ImVec2(rect.Min.x - 1.f, rect.Min.y - 1.f),
            ImVec2(rect.Max.x,       rect.Min.y - 1.f),
            stroke_color);
        window->DrawList->AddLine(
            ImVec2(rect.Min.x - 1.f, rect.Min.y - 1.f),
            ImVec2(rect.Min.x - 1.f, rect.Max.y),
            stroke_color);
        window->DrawList->AddLine(
            ImVec2(rect.Max.x, rect.Min.y - 1.f),
            ImVec2(rect.Max.x, rect.Max.y),
            stroke_color);
        window->DrawList->AddLine(
            ImVec2(rect.Min.x, rect.Max.y),
            ImVec2(rect.Max.x, rect.Max.y),
            draw->get_clr(clr->window.gradient));
    }

    const ImRect text_rect(
        rect.Min + ImVec2(padding_left, 0.f),
        rect.Max - ImVec2(padding_right, 0.f)
    );

    draw->text_clipped_outline(window->DrawList, var->font.tahoma,
        text_rect.Min, text_rect.Max,
        selected ? draw->get_clr(clr->widgets.text) : draw->get_clr(clr->widgets.text_inactive),
        label.data(), NULL, NULL, ImVec2(0.f, 0.5f));

    PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(-1.f, g.Style.ItemSpacing.y));
    gui->sameline();
    PopStyleVar();

    return pressed;
}