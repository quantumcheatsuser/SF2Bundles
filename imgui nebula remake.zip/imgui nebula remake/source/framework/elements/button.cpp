#include "../settings/functions.h"

bool c_gui::button(std::string_view label, int val)
{
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label.data());

    ImVec2 pos = window->DC.CursorPos;

    float width = (val > 0) 
        ? (GetContentRegionAvail().x - style.ItemSpacing.x * (val - 1)) / val 
        : CalcTextSize(label.data()).x + 22.0f; 
        
    const ImRect rect(pos, pos + ImVec2(width, elements->widgets.dropdown_height));
    ItemSize(rect, style.FramePadding.y);
    if (!ItemAdd(rect, id))
        return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(rect, id, &hovered, &held, 0);

    std::string anim_id = std::string("button_") + label.data();

    ImVec4 target_border = (var->window.hover_hightlight && hovered) 
        ? clr->accent 
        : clr->widgets.stroke_two;
    ImVec4 border_color = gui->animate_color((anim_id + "_border").c_str(), target_border, 0.15f);

    draw->rect_filled(window->DrawList, rect.Min, rect.Max, ColorConvertFloat4ToU32(border_color));
    draw->rect(window->DrawList, rect.Min + ImVec2(1, 1), rect.Max - ImVec2(1, 1), draw->get_clr(clr->window.stroke));
    draw->fade_rect_filled(window->DrawList, rect.Min + ImVec2(2, 2), rect.Max - ImVec2(2, 2), draw->get_clr(clr->window.background_two), draw->get_clr(clr->window.background_one), vertically);
    draw->text_clipped_outline(window->DrawList, var->font.tahoma, rect.Min, rect.Max, draw->get_clr(clr->widgets.text), label.data(), NULL, NULL, ImVec2(0.5f, 0.5f));

    return pressed;
}
