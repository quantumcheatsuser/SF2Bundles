#include "../settings/functions.h"
#include <chrono>
#include <cmath>
#include <unordered_map>
#include <string>

struct animation_settings
{
    float tweening_speed = 0.25f;
    int easing_style = 4; 
    int easing_direction = 2; 
    bool enabled = true;
} g_anim_settings;

namespace animation
{

    float ease_linear(float t) { return t; }

    float ease_in_quad(float t) { return t * t; }
    float ease_out_quad(float t) { return 1.0f - (1.0f - t) * (1.0f - t); }
    float ease_in_out_quad(float t) {
        return t < 0.5f ? 2.0f * t * t : 1.0f - powf(-2.0f * t + 2.0f, 2.0f) / 2.0f;
    }

    float ease_in_quint(float t) { return t * t * t * t * t; }
    float ease_out_quint(float t) { return 1.0f - powf(1.0f - t, 5.0f); }
    float ease_in_out_quint(float t) {
        return t < 0.5f 
            ? 16.0f * t * t * t * t * t 
            : 1.0f - powf(-2.0f * t + 2.0f, 5.0f) / 2.0f;
    }

    float ease_in_expo(float t) { return t == 0.0f ? 0.0f : powf(2.0f, 10.0f * t - 10.0f); }
    float ease_out_expo(float t) { return t == 1.0f ? 1.0f : 1.0f - powf(2.0f, -10.0f * t); }
    float ease_in_out_expo(float t) {
        if (t == 0.0f) return 0.0f;
        if (t == 1.0f) return 1.0f;
        return t < 0.5f 
            ? powf(2.0f, 20.0f * t - 10.0f) / 2.0f
            : (2.0f - powf(2.0f, -20.0f * t + 10.0f)) / 2.0f;
    }

    float ease_in_sine(float t) { return 1.0f - cosf(t * 1.57079632679f); }
    float ease_out_sine(float t) { return sinf(t * 1.57079632679f); }
    float ease_in_out_sine(float t) { return -(cosf(3.14159265359f * t) - 1.0f) / 2.0f; }

    float apply_easing(float t)
    {
        if (!g_anim_settings.enabled)
            return 1.0f; 

        t = ImClamp(t, 0.0f, 1.0f);

        switch (g_anim_settings.easing_style)
        {
            case 0: 
                return ease_linear(t);
                
            case 1: 
                switch (g_anim_settings.easing_direction)
                {
                    case 0: return ease_in_quad(t);
                    case 1: return ease_out_quad(t);
                    case 2: return ease_in_out_quad(t);
                }
                break;
                
            case 2: 
                switch (g_anim_settings.easing_direction)
                {
                    case 0: return ease_in_quint(t);
                    case 1: return ease_out_quint(t);
                    case 2: return ease_in_out_quint(t);
                }
                break;
                
            case 3: 
                switch (g_anim_settings.easing_direction)
                {
                    case 0: return ease_in_expo(t);
                    case 1: return ease_out_expo(t);
                    case 2: return ease_in_out_expo(t);
                }
                break;
                
            case 4: 
                switch (g_anim_settings.easing_direction)
                {
                    case 0: return ease_in_sine(t);
                    case 1: return ease_out_sine(t);
                    case 2: return ease_in_out_sine(t);
                }
                break;
        }
        
        return ease_in_out_quint(t); 
    }

    double get_time()
    {
        static auto start_time = std::chrono::high_resolution_clock::now();
        auto current_time = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = current_time - start_time;
        return elapsed.count();
    }
}

struct anim_state
{
    float start_value;
    float target_value;
    float current_value;
    double start_time;
    float duration;
    bool active;
    bool completed;

    anim_state() 
        : start_value(0.f), target_value(0.f), current_value(0.f)
        , start_time(0.0), duration(0.25f), active(false), completed(false)
    {}

    void start(float from, float to, float speed)
    {
        start_value = from;
        target_value = to;
        current_value = from;
        start_time = animation::get_time();
        duration = speed > 0.0f ? speed : g_anim_settings.tweening_speed;
        active = true;
        completed = false;
    }

    float update()
    {
        if (!g_anim_settings.enabled)
        {
            current_value = target_value;
            completed = true;
            active = false;
            return current_value;
        }
        
        if (!active || completed)
            return current_value;

        double elapsed = animation::get_time() - start_time;
        float t = static_cast<float>(elapsed / duration);
        
        if (t >= 1.0f)
        {
            current_value = target_value;
            completed = true;
            active = false;
            return current_value;
        }

        float eased_t = animation::apply_easing(t);
        current_value = start_value + (target_value - start_value) * eased_t;

        return current_value;
    }

    bool is_animating() const { return active && !completed; }
};

struct color_anim_state
{
    ImVec4 start_color;
    ImVec4 target_color;
    ImVec4 current_color;
    double start_time;
    float duration;
    bool active;
    bool completed;

    color_anim_state()
        : start_color(0, 0, 0, 0), target_color(0, 0, 0, 0), current_color(0, 0, 0, 0)
        , start_time(0.0), duration(0.25f), active(false), completed(false)
    {}

    void start(const ImVec4& from, const ImVec4& to, float speed)
    {
        start_color = from;
        target_color = to;
        current_color = from;
        start_time = animation::get_time();
        duration = speed > 0.0f ? speed : g_anim_settings.tweening_speed;
        active = true;
        completed = false;
    }

    ImVec4 update()
    {
        if (!g_anim_settings.enabled)
        {
            current_color = target_color;
            completed = true;
            active = false;
            return current_color;
        }
        
        if (!active || completed)
            return current_color;

        double elapsed = animation::get_time() - start_time;
        float t = static_cast<float>(elapsed / duration);
        
        if (t >= 1.0f)
        {
            current_color = target_color;
            completed = true;
            active = false;
            return current_color;
        }

        float eased_t = animation::apply_easing(t);
        
        current_color.x = start_color.x + (target_color.x - start_color.x) * eased_t;
        current_color.y = start_color.y + (target_color.y - start_color.y) * eased_t;
        current_color.z = start_color.z + (target_color.z - start_color.z) * eased_t;
        current_color.w = start_color.w + (target_color.w - start_color.w) * eased_t;

        return current_color;
    }

    bool is_animating() const { return active && !completed; }
};

float c_gui::animate_float(const char* id, float target, float speed)
{
    static std::unordered_map<std::string, anim_state> animations;
    
    std::string key = std::string(id);

    anim_state& anim = animations[key];

    if (!anim.is_animating() && anim.current_value != target)
    {
        anim.start(anim.current_value, target, speed);
    }
    else if (anim.is_animating() && anim.target_value != target)
    {
        
        anim.start(anim.current_value, target, speed);
    }

    return anim.update();
}

ImVec4 c_gui::animate_color(const char* id, const ImVec4& target, float speed)
{
    static std::unordered_map<std::string, color_anim_state> animations;
    
    std::string key = std::string(id);

    color_anim_state& anim = animations[key];

    if (!anim.is_animating())
    {
        bool colors_different = 
            anim.current_color.x != target.x ||
            anim.current_color.y != target.y ||
            anim.current_color.z != target.z ||
            anim.current_color.w != target.w;

        if (colors_different)
        {
            anim.start(anim.current_color, target, speed);
        }
    }
    else if (anim.target_color.x != target.x || 
             anim.target_color.y != target.y || 
             anim.target_color.z != target.z || 
             anim.target_color.w != target.w)
    {
        
        anim.start(anim.current_color, target, speed);
    }

    return anim.update();
}

float c_gui::lerp_float(float current, float target, float speed)
{
    float delta = ImGui::GetIO().DeltaTime;
    return current + (target - current) * ImClamp(speed * delta * 10.0f, 0.0f, 1.0f);
}

void c_gui::set_animation_enabled(bool enabled)
{
    g_anim_settings.enabled = enabled;
}

void c_gui::set_animation_speed(float speed)
{
    g_anim_settings.tweening_speed = ImClamp(speed, 0.01f, 2.0f);
}

void c_gui::set_animation_easing_style(int style)
{
    g_anim_settings.easing_style = ImClamp(style, 0, 4);
}

void c_gui::set_animation_easing_direction(int direction)
{
    g_anim_settings.easing_direction = ImClamp(direction, 0, 2);
}

bool c_gui::get_animation_enabled()
{
    return g_anim_settings.enabled;
}

float c_gui::get_animation_speed()
{
    return g_anim_settings.tweening_speed;
}

int c_gui::get_animation_easing_style()
{
    return g_anim_settings.easing_style;
}

int c_gui::get_animation_easing_direction()
{
    return g_anim_settings.easing_direction;
}
