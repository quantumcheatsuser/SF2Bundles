#define IMGUI_DEFINE_MATH_OPERATORS
#define _CRT_NO_SECURE_NO_WARNINGS
#include "imgui.h"
#include "imgui_internal.h"
#include "menu_cache/render_cache.h"
#include "settings/functions.h"
#include "settings/themes.h"
#include <Windows.h>
#include <algorithm>
#include <chrono>
#include <ctime>
#include <sstream>
#include <string>
#include <vector>

static bool g_show_watermark = true;
static bool g_show_keybinds = true;

bool enable_vsync = false;

struct KeybindInfo {
    std::string name;
    int* key_ptr;
    int* mode_ptr;
    bool* enabled_ptr;
    float alpha = 0.0f;
    bool toggle_state = false;
};

static std::vector<KeybindInfo> g_keybind_registry;

void register_keybind(const char* name, int* key, int* mode, bool* enabled) {
    for (auto& kb : g_keybind_registry) {
        if (kb.name == name) {
            kb.key_ptr = key;
            kb.mode_ptr = mode;
            kb.enabled_ptr = enabled;
            return;
        }
    }
    g_keybind_registry.push_back({ name, key, mode, enabled });
}

void c_gui::render() {
    CACHE.begin_frame();

    if (GetAsyncKeyState(var->gui.menu_key) & 0x1)
        var->gui.menu_opened = !var->gui.menu_opened;

    var->gui.menu_alpha =
        ImClamp(var->gui.menu_alpha +
            (gui->fixed_speed(8.f) * (var->gui.menu_opened ? 1.f : -1.f)),
            0.f, 1.f);

    if (var->gui.menu_alpha > 0.01f) {
        gui->push_style_var(ImGuiStyleVar_Alpha, var->gui.menu_alpha);

        ImGuiStyle* style = &GetStyle();
        {
            style->WindowPadding = var->window.padding;
            style->PopupBorderSize = var->window.border_size;
            style->WindowBorderSize = var->window.border_size;
            style->ItemSpacing = var->window.spacing;
            style->WindowShadowSize =
                var->gui.menu_glow ? var->window.shadow_size : 0.f;
            style->ScrollbarSize = var->window.scrollbar_size;
            style->Colors[ImGuiCol_WindowShadow] = {
                clr->accent.Value.x, clr->accent.Value.y, clr->accent.Value.z,
                var->window.shadow_alpha };
        }

        gui->set_next_window_size_constraints(ImVec2(455, 605),
            GetIO().DisplaySize);
        gui->begin("Nebula Remake", nullptr, var->window.flags);
        {
            static int subtabs;
            draw->window_decorations();

            gui->set_cursor_pos(ImVec2(10, 29));
            gui->begin_group();
            {
                gui->sub_section("Combat", 0, subtabs, 4);
                gui->sub_section("Visuals", 1, subtabs, 4);
                gui->sub_section("Players", 2, subtabs, 4);
                gui->sub_section("Settings", 3, subtabs, 4);
            }
            gui->end_group();

            gui->set_cursor_pos(ImVec2(10, 49));
            gui->begin_content();
            {
                static int prev_subtabs = subtabs;
                static float tab_content_alpha = 1.0f;

                if (var->gui.tab_animation && prev_subtabs != subtabs) {
                    tab_content_alpha = 0.0f;
                    prev_subtabs = subtabs;
                }

                if (var->gui.tab_animation)
                    tab_content_alpha = ImMin(tab_content_alpha + gui->fixed_speed(6.f), 1.0f);

                gui->push_style_var(ImGuiStyleVar_Alpha, GetStyle().Alpha * tab_content_alpha);

                if (subtabs == 2) {
                }

                else if (subtabs == 1) {
                    static int vis_tab = 0;
                    const char* vis_tabs[] = { "Left", "Right" };

                    gui->begin_group();
                    {
                        gui->begin_child("Widgets A", 2, 1);
                        {
                            static bool cb1 = false;
                            gui->checkbox("Checkbox", &cb1);

                            static bool cb2 = true;
                            static int kb_key = 0;
                            static int kb_mode = 0;
                            gui->checkbox("Checkbox + Keybind", &cb2, &kb_key, &kb_mode);

                            static bool fold = false;
                            if (gui->begin_folding_checkbox("Folding Checkbox", &fold)) {
                                static bool nested = false;
                                gui->checkbox("Nested Checkbox", &nested);

                                static int nested_int = 50;
                                gui->slider_int("Nested Slider", &nested_int, 0, 100);

                                gui->end_folding_checkbox();
                            }

                            static bool fold2 = true;
                            static int fold_key = 0;
                            static int fold_mode = 0;
                            if (gui->begin_folding_checkbox("Folding + Keybind", &fold2, &fold_key, &fold_mode)) {
                                static float nested_f = 3.f;
                                gui->slider_float("Nested Float", &nested_f, 0.f, 10.f);
                                gui->end_folding_checkbox();
                            }

                            static int sl_int = 25;
                            gui->slider_int("Slider Int", &sl_int, 0, 100);

                            static float sl_float = 1.5f;
                            gui->slider_float("Slider Float", &sl_float, 0.f, 10.f);

                            static int sl_int_nolabel = 50;
                            gui->slider_int("sl_nolabel", &sl_int_nolabel, 0, 100, true);

                            static float sl_float_fmt = 44.f;
                            gui->slider_float("Slider Fmt", &sl_float_fmt, 0.f, 100.f, false, "%.1f%%");

                            static int drop = 0;
                            const char* drop_items[] = { "Option A", "Option B", "Option C", "Option D" };
                            gui->dropdown("Dropdown", &drop, drop_items, IM_ARRAYSIZE(drop_items));

                            static int drop_nolabel = 0;
                            const char* drop_nl_items[] = { "One", "Two", "Three" };
                            gui->dropdown("drop_nolabel", &drop_nolabel, drop_nl_items, IM_ARRAYSIZE(drop_nl_items), true);

                            static std::vector<int> multi = { 1, 0, 1, 0 };
                            const char* multi_items[] = { "Alpha", "Beta", "Gamma", "Delta" };
                            gui->multi_dropdown("Multi Dropdown", multi, multi_items, IM_ARRAYSIZE(multi_items));
                        }
                        gui->end_child();
                    }
                    gui->end_group();

                    gui->sameline();

                    gui->begin_group();
                    {
                        gui->begin_multi_section("Widgets B", vis_tab, vis_tabs,
                            IM_ARRAYSIZE(vis_tabs), 2, 1);
                        {
                            if (vis_tab == 0) {
                                static char tf_buf[128] = "";
                                gui->text_field("Text Field", tf_buf, sizeof(tf_buf), "Type here...");

                                static char tf_buf2[128] = "Hello";
                                gui->text_field("Text Field 2", tf_buf2, sizeof(tf_buf2));

                                if (gui->button("Button"))
                                    (void)0;

                                static float col1[4] = { 1.f, 0.2f, 0.2f, 1.f };
                                gui->color_edit("##col1", col1, true, true);

                                static float col2[4] = { 0.2f, 0.6f, 1.f, 1.f };
                                gui->label_color_edit("Label Color", col2);

                                static float col3[4] = { 0.4f, 1.f, 0.4f, 0.8f };
                                gui->label_color_edit("No Alpha", col3, false);

                                static int lkb_key = 0;
                                gui->label_keybind("Label Keybind", &lkb_key);

                                static int raw_key = 0;
                                static int raw_mode = 0;
                                gui->keybind("Keybind", &raw_key, &raw_mode);
                            }
                            else {
                                if (gui->begin_table("##demo_table", 3)) {
                                    gui->table_next_row();
                                    gui->table_set_column_index(0); ImGui::Text("Name");
                                    gui->table_set_column_index(1); ImGui::Text("Value");
                                    gui->table_set_column_index(2); ImGui::Text("Status");

                                    gui->table_next_row();
                                    gui->table_set_column_index(0); ImGui::Text("Alpha");
                                    gui->table_set_column_index(1); ImGui::Text("100");
                                    gui->table_set_column_index(2); ImGui::Text("On");

                                    gui->table_next_row();
                                    gui->table_set_column_index(0); ImGui::Text("Beta");
                                    gui->table_set_column_index(1); ImGui::Text("50");
                                    gui->table_set_column_index(2); ImGui::Text("Off");

                                    gui->table_next_row();
                                    gui->table_set_column_index(0); ImGui::Text("Gamma");
                                    gui->table_set_column_index(1); ImGui::Text("75");
                                    gui->table_set_column_index(2); ImGui::Text("On");

                                    gui->end_table();
                                }

                                static bool sel1 = false;
                                gui->selectable("Selectable A", &sel1, ImVec2(0, 0));

                                static bool sel2 = true;
                                gui->selectable("Selectable B", &sel2, ImVec2(0, 0));
                            }
                        }
                        gui->end_multi_section();
                    }
                    gui->end_group();
                }

                else if (subtabs == 0) {
                    gui->begin_group();
                    {
                        gui->begin_child("Aim Assist", 2, 1);
                        {
                            static bool enabled = true;
                            static int key;
                            static int mode;
                            SetCursorPosY(GetCursorPosY() - 3.f);
                            gui->checkbox("Enabled", &enabled, &key, &mode);
                            register_keybind("Enabled", &key, &mode, &enabled);

                            static int fov = 90;
                            gui->slider_int("Field Of View", &fov, 0, 100);

                            static int fov_type = 0;
                            const char* fov_type_items[2] = { "Static", "Dynamic" };
                            gui->dropdown("fov type", &fov_type, fov_type_items,
                                IM_ARRAYSIZE(fov_type_items), true);

                            static float horizontal = 30;
                            gui->slider_float("Horizontal Smoothing", &horizontal, 0, 100);

                            static float vertical = 12;
                            gui->slider_float("Vertical Smoothing", &vertical, 0, 100);

                            static std::vector<int> checks = { 1, 1, 1 };
                            const char* checks_items[3] = { "Team Check", "Alive Check",
                                                           "Enemy Check" };
                            gui->multi_dropdown("Checks", checks, checks_items,
                                IM_ARRAYSIZE(checks_items));

                            static std::vector<int> hitboxes = { 1, 0, 1, 0, 1, 0 };
                            const char* hitboxes_items[6] = { "Head", "Neck", "Stomach",
                                                             "Body", "Arms", "Legs" };
                            gui->multi_dropdown("Hitboxes", hitboxes, hitboxes_items,
                                IM_ARRAYSIZE(hitboxes_items));

                            static bool randomize = false;
                            gui->checkbox("Randomize Position", &randomize);

                            static int hitscan_type = 0;
                            const char* hitscan_type_items[2] = { "Mouse", "Distance" };
                            gui->dropdown("Hitscan Type", &hitscan_type, fov_type_items,
                                IM_ARRAYSIZE(fov_type_items));

                            static bool readjustment = false;
                            static int rkey;
                            static int rmode;
                            gui->checkbox("Readjustment", &readjustment, &rkey, &rmode);
                            register_keybind("Readjustment", &rkey, &rmode, &readjustment);

                            static bool deadzone = true;
                            gui->checkbox("Dead Zone", &deadzone);

                            static float dzone = 44;
                            gui->slider_float("dzone", &dzone, 0, 100, true);

                            static bool stutter = true;
                            gui->checkbox("Stutter", &stutter);

                            static float stslider = 25;
                            gui->slider_float("stslider", &stslider, 0, 100, true, "%.1ft");
                        }
                        gui->end_child();
                    }
                    gui->end_group();

                    gui->sameline();

                    gui->begin_group();
                    {
                        static int multi_tab = 0;
                        const char* multi_tabs[] = { "Hi", "Hello", "Sick" };

                        gui->begin_multi_section("right_panel", multi_tab, multi_tabs,
                            IM_ARRAYSIZE(multi_tabs), 2, 1);
                        {
                            if (multi_tab == 0) {
                                static bool toggle0 = false;
                                gui->checkbox("Toggle", &toggle0);

                                static int slider0 = 34;
                                gui->slider_int("Slider", &slider0, 1, 100);

                                static float hello0 = 2.f;
                                gui->slider_float("Hello!", &hello0, 0.f, 10.f);
                            }
                            else if (multi_tab == 1) {
                                static bool toggle1 = true;
                                gui->checkbox("Toggle", &toggle1);

                                static int slider1 = 34;
                                gui->slider_int("Slider", &slider1, 1, 100);

                                static float hello1 = 2.f;
                                gui->slider_float("Hello!", &hello1, 0.f, 10.f);

                                static bool folding_group = false;
                                static int fkey;
                                static int fmode;
                                register_keybind("Folding Group", &fkey, &fmode, &folding_group);

                                if (gui->begin_folding_checkbox("Folding Group", &folding_group,
                                    &fkey, &fmode)) {
                                    static bool nested_toggle = false;
                                    gui->checkbox("Nested Toggle", &nested_toggle);

                                    static int nested_slider = 50;
                                    gui->slider_int("Nested Slider", &nested_slider, 0, 100);

                                    static float nested_float = 5.f;
                                    gui->slider_float("Nested Float", &nested_float, 0.f, 10.f);

                                    gui->end_folding_checkbox();
                                }
                            }
                            else if (multi_tab == 2) {
                                static bool group_val = true;
                                if (gui->begin_folding_checkbox("Group", &group_val)) {
                                    static bool toggle2 = false;
                                    gui->checkbox("Toggle", &toggle2);

                                    static int slider2 = 34;
                                    gui->slider_int("Slider", &slider2, 1, 100);

                                    static float hello2 = 2.f;
                                    gui->slider_float("Hello!", &hello2, 0.f, 10.f);

                                    gui->end_folding_checkbox();
                                }
                            }
                        }
                        gui->end_multi_section();
                    }
                    gui->end_group();
                }
                else if (subtabs == 3) {
                    gui->begin_group();
                    {
                        gui->begin_child("Menu", 2, 1);
                        {
                            gui->label_keybind("Open/Close", &var->gui.menu_key);

                            gui->checkbox("Watermark", &g_show_watermark);
                            gui->checkbox("Keybinds", &g_show_keybinds);
                            gui->checkbox("Tab Animation", &var->gui.tab_animation);

                            if (gui->begin_folding_checkbox("Menu Glow", &var->gui.menu_glow)) {
                                gui->slider_float("Thickness", &var->window.shadow_size, 10.f, 250.f);
                                gui->end_folding_checkbox();
                            }

                            static bool anim_enabled = true;
                            static float anim_speed = 0.25f;
                            static int easing_style = 4;
                            static int easing_direction = 2;

                            if (gui->begin_folding_checkbox("Animations", &anim_enabled)) {
                                gui->set_animation_enabled(anim_enabled);

                                if (gui->slider_float("Speed", &anim_speed, 0.01f, 1.0f, false, "%.2fs")) {
                                    gui->set_animation_speed(anim_speed);
                                }

                                const char* easing_styles[] = { "Linear", "Quad", "Quint", "Exponential", "Sine" };
                                if (gui->dropdown("Easing Style", &easing_style, easing_styles, 5)) {
                                    gui->set_animation_easing_style(easing_style);
                                }

                                const char* easing_directions[] = { "In", "Out", "InOut" };
                                if (gui->dropdown("Direction", &easing_direction, easing_directions, 3)) {
                                    gui->set_animation_easing_direction(easing_direction);
                                }

                                gui->end_folding_checkbox();
                            }
                            else {
                                gui->set_animation_enabled(anim_enabled);
                            }

                            extern bool enable_vsync;
                            gui->checkbox("VSync", &enable_vsync);

                            gui->label_color_edit("Accent", (float*)&clr->accent);
                            gui->label_color_edit("Background Outer", (float*)&clr->window.background_one);
                            gui->label_color_edit("Background Inner", (float*)&clr->window.background_two);
                            gui->label_color_edit("Outline", (float*)&clr->window.stroke);
                            gui->label_color_edit("Inline", (float*)&clr->window.inline_col);
                            gui->label_color_edit("Gradient", (float*)&clr->window.gradient);
                            gui->label_color_edit("Widget Outline", (float*)&clr->widgets.stroke_two);
                            gui->label_color_edit("Text Color", (float*)&clr->widgets.text);
                            gui->label_color_edit("Text Inactive", (float*)&clr->widgets.text_inactive);
                            gui->label_color_edit("Tab Background", (float*)&clr->widgets.tab_background);


                        }
                        gui->end_child();
                    }
                    gui->end_group();
                }
            }
            gui->pop_style_var();
            gui->end_content();
        }
        gui->end();
        gui->pop_style_var();

        if (is_animation_window_open()) {
            ImGuiID slider_id = get_animation_window_slider_id();
            SliderRandomization* rand_data = get_slider_randomization(slider_id);

            if (rand_data) {
                gui->push_style_var(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
                gui->push_style_var(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
                gui->push_style_var(ImGuiStyleVar_WindowBorderSize, 0.0f);

                gui->set_next_window_pos(get_animation_window_pos(), ImGuiCond_Appearing);
                gui->begin("##SliderAnimation", nullptr,
                    ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                    ImGuiWindowFlags_AlwaysAutoResize |
                    ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoMove);
                {
                    ImDrawList* draw_list = GetWindowDrawList();
                    ImDrawList* bg_draw_list = GetBackgroundDrawList();
                    ImVec2 pos = GetWindowPos();

                    const float title_height = var->window.titlebar;
                    const float content_padding_x = elements->content.padding.x;
                    const float content_padding_y = elements->content.padding.y;
                    const float widget_spacing = elements->widgets.spacing.y;
                    const float total_width = 220.0f;

                    float content_height = content_padding_y;
                    content_height += elements->widgets.checkbox_size.y + widget_spacing;
                    content_height += (14.0f + elements->widgets.dropdown_height) + widget_spacing;
                    content_height += (14.0f + elements->widgets.slider_height) + widget_spacing;
                    content_height += (14.0f + elements->widgets.slider_height) + widget_spacing;
                    content_height += (14.0f + elements->widgets.slider_height);
                    content_height += content_padding_y;

                    const float total_height = title_height + content_height;

                    if (!IsWindowAppearing()) {
                        if (IsMouseClicked(0) || IsMouseClicked(1)) {
                            ImVec2 mouse_pos = GetIO().MousePos;
                            ImRect window_rect(pos, pos + ImVec2(total_width, total_height));
                            if (!window_rect.Contains(mouse_pos)) {
                                set_animation_window_open(false);
                            }
                        }
                    }

                    ImU32 stroke_color = draw->get_clr(clr->window.stroke);
                    ImU32 gradient_color = draw->get_clr(clr->window.gradient);
                    ImU32 bg_one_color = draw->get_clr(clr->window.background_one);
                    ImU32 accent_color = draw->get_clr(clr->accent);
                    ImU32 shadow_color = draw->get_clr({ 0, 0, 0, 0.5f });
                    ImU32 text_color_base = ImColor(clr->widgets.text);
                    ImU32 inline_color = draw->get_clr(clr->window.inline_col);

                    draw->rect(bg_draw_list, pos - ImVec2(1, 1),
                        ImVec2(pos.x + total_width + 1, pos.y + total_height + 1),
                        shadow_color);

                    draw->rect_filled(draw_list, pos,
                        ImVec2(pos.x + total_width, pos.y + total_height),
                        bg_one_color);

                    draw->rect_filled(
                        draw_list, ImVec2(pos.x + 1, pos.y + 4),
                        ImVec2(pos.x + total_width - 1, pos.y + total_height - 1),
                        gradient_color);

                    draw->fade_rect_filled(draw_list, ImVec2(pos.x + 2, pos.y + 5),
                        ImVec2(pos.x + total_width - 2, pos.y + 21),
                        inline_color, gradient_color,
                        fade_direction::vertically);

                    draw->rect_filled(draw_list, ImVec2(pos.x + 1, pos.y + 1),
                        ImVec2(pos.x + total_width - 1, pos.y + 3),
                        accent_color);

                    draw->rect_filled(draw_list, ImVec2(pos.x, pos.y + 3),
                        ImVec2(pos.x + total_width, pos.y + 4),
                        stroke_color);

                    const float title_y = 6.0f;
                    ImVec2 title_pos(pos.x + 6.0f, pos.y + title_y);

                    draw->text_outline(draw_list, var->font.tahoma,
                        var->font.tahoma->FontSize, title_pos,
                        text_color_base, "Animation");

                    SetCursorPos(ImVec2(content_padding_x, title_height + content_padding_y));

                    gui->push_style_var(ImGuiStyleVar_ItemSpacing, elements->widgets.spacing);

                    const float content_width = total_width - (content_padding_x * 2);

                    char unique_id[64];
                    snprintf(unique_id, sizeof(unique_id), "anim_window_%u", slider_id);
                    PushID(unique_id);

                    BeginChild("##anim_content", ImVec2(content_width, 0), false,
                        ImGuiWindowFlags_NoScrollbar);

                    gui->checkbox("Randomize Slider", &rand_data->enabled);

                    const char* style_names[] = { "Linear", "Quadratic", "Quintic", "Exponential", "Sine" };
                    gui->dropdown("Style", &rand_data->style, style_names, 5, false);

                    gui->slider_float("Speed", &rand_data->speed, 0.1f, 10.0f, false);
                    gui->slider_float("Minimum value", &rand_data->min_value, 0.0f, 100.0f, false);
                    gui->slider_float("Maximum value", &rand_data->max_value, 0.0f, 100.0f, false);

                    EndChild();
                    PopID();

                    if (rand_data->min_value > rand_data->max_value) {
                        float temp = rand_data->min_value;
                        rand_data->min_value = rand_data->max_value;
                        rand_data->max_value = temp;
                    }

                    gui->pop_style_var();

                    SetCursorPos(ImVec2(total_width, total_height));
                }
                gui->end_content();
            }
            gui->end();
            gui->pop_style_var(3);
        }
    }
}

void c_gui::render_watermark() {
    static float watermark_alpha = 0.0f;
    watermark_alpha =
        ImClamp(watermark_alpha +
            gui->fixed_speed(8.0f) * (g_show_watermark ? 1.0f : -1.0f),
            0.0f, 1.0f);

    if (watermark_alpha > 0.01f) {
        static auto start_time = std::chrono::steady_clock::now();
        static double cached_cpu_usage = 0.0;
        static auto last_cpu_update = std::chrono::steady_clock::now();
        static ULARGE_INTEGER lastCPU = { 0 }, lastSysCPU = { 0 }, lastUserCPU = { 0 };
        static int numProcessors = 0;
        static HANDLE self = nullptr;
        static bool cpu_initialized = false;

        if (!cpu_initialized) {
            SYSTEM_INFO sysInfo;
            GetSystemInfo(&sysInfo);
            numProcessors = sysInfo.dwNumberOfProcessors;
            self = GetCurrentProcess();

            FILETIME ftime, fsys, fuser;
            GetSystemTimeAsFileTime(&ftime);
            memcpy(&lastCPU, &ftime, sizeof(FILETIME));
            GetProcessTimes(self, &ftime, &ftime, &fsys, &fuser);
            memcpy(&lastSysCPU, &fsys, sizeof(FILETIME));
            memcpy(&lastUserCPU, &fuser, sizeof(FILETIME));
            cpu_initialized = true;
        }

        auto current_time = std::chrono::steady_clock::now();
        auto time_since_update =
            std::chrono::duration_cast<std::chrono::milliseconds>(current_time - last_cpu_update).count();

        static int cached_mon = 1, cached_mday = 1, cached_year = 2024;

        if (time_since_update > 500) {
            FILETIME ftime, fsys, fuser;
            ULARGE_INTEGER now_cpu, sys, user;

            GetSystemTimeAsFileTime(&ftime);
            memcpy(&now_cpu, &ftime, sizeof(FILETIME));

            if (GetProcessTimes(self, &ftime, &ftime, &fsys, &fuser)) {
                memcpy(&sys, &fsys, sizeof(FILETIME));
                memcpy(&user, &fuser, sizeof(FILETIME));

                double cpu_diff = (double)((sys.QuadPart - lastSysCPU.QuadPart) +
                    (user.QuadPart - lastUserCPU.QuadPart));
                double time_diff = (double)(now_cpu.QuadPart - lastCPU.QuadPart);

                if (time_diff > 0) {
                    cached_cpu_usage = (cpu_diff / time_diff / numProcessors) * 100.0;
                    if (cached_cpu_usage < 0.0) cached_cpu_usage = 0.0;
                    if (cached_cpu_usage > 100.0) cached_cpu_usage = 100.0;
                }

                lastCPU = now_cpu;
                lastUserCPU = user;
                lastSysCPU = sys;
            }

            time_t now = time(0);
            tm* ltm = localtime(&now);
            if (ltm) {
                cached_mon = ltm->tm_mon + 1;
                cached_mday = ltm->tm_mday;
                cached_year = 1900 + ltm->tm_year;
            }

            last_cpu_update = current_time;
        }

        gui->push_style_var(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        gui->push_style_var(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
        gui->push_style_var(ImGuiStyleVar_WindowBorderSize, 0.0f);

        gui->set_next_window_pos(ImVec2(20, 20), ImGuiCond_FirstUseEver);
        gui->begin("##watermark", nullptr,
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_AlwaysAutoResize |
            ImGuiWindowFlags_NoScrollbar);
        {
            ImDrawList* draw_list = GetWindowDrawList();
            ImDrawList* bg_draw_list = GetBackgroundDrawList();
            ImVec2 pos = GetWindowPos();

            auto uptime_seconds = std::chrono::duration_cast<std::chrono::seconds>(
                current_time - start_time).count();
            int uptime_hours = (int)(uptime_seconds / 3600);
            int uptime_minutes = (int)((uptime_seconds % 3600) / 60);
            int uptime_secs = (int)(uptime_seconds % 60);

            float fps = GetIO().Framerate;

            char watermark_text[256];
            snprintf(watermark_text, sizeof(watermark_text),
                "nebula.remake",
                fps, cached_cpu_usage, uptime_hours, uptime_minutes, uptime_secs,
                cached_mon, cached_mday, cached_year);

            const float text_height = CACHE.watermark.text_height;
            const float actual_text_width = CalcTextSize(watermark_text).x;

            const float padding_left = 5.0f;
            const float padding_right = 10.0f;
            const float total_width = actual_text_width + padding_left + padding_right;
            const float total_height = 23.0f;

            ImU32 stroke_color = CACHE.color.get_or_calculate(clr->window.stroke, watermark_alpha);
            ImU32 gradient_color = CACHE.color.get_or_calculate(clr->window.gradient, watermark_alpha);
            ImU32 bg_two_color = CACHE.color.get_or_calculate(clr->window.background_two, watermark_alpha);
            ImU32 accent_color_u32 = CACHE.color.get_or_calculate(clr->accent, watermark_alpha);
            ImU32 text_color_u32 = CACHE.color.get_or_calculate(clr->widgets.text, watermark_alpha);
            ImU32 black_outline = IM_COL32(0, 0, 0, (int)(255 * watermark_alpha));
            ImU32 shadow_color = CACHE.color.get_or_calculate(ImVec4(0, 0, 0, 0.5f), watermark_alpha);

            draw->rect(bg_draw_list, pos - ImVec2(1, 1),
                ImVec2(pos.x + total_width + 1, pos.y + total_height + 1),
                shadow_color);

            draw->rect_filled(draw_list, pos,
                ImVec2(pos.x + total_width, pos.y + total_height),
                stroke_color);

            draw->fade_rect_filled(
                draw_list, ImVec2(pos.x + 1, pos.y + 1),
                ImVec2(pos.x + total_width - 1, pos.y + total_height - 1),
                gradient_color, bg_two_color, fade_direction::vertically);

            draw->rect_filled(draw_list, ImVec2(pos.x + 1, pos.y + 1),
                ImVec2(pos.x + total_width - 1, pos.y + 3),
                accent_color_u32);

            draw->rect_filled(draw_list, ImVec2(pos.x + 1, pos.y + 3),
                ImVec2(pos.x + total_width - 1, pos.y + 4),
                stroke_color);

            const float text_y = 3.0f + ((total_height - 3.0f - text_height) * 0.5f);
            float text_x = padding_left;

            auto draw_text_outlined = [&](const char* text, float& x_pos, ImU32 color) {
                ImVec2 text_pos(pos.x + x_pos, pos.y + text_y);
                draw_list->AddText(ImVec2(text_pos.x - 1, text_pos.y - 1), black_outline, text);
                draw_list->AddText(ImVec2(text_pos.x,     text_pos.y - 1), black_outline, text);
                draw_list->AddText(ImVec2(text_pos.x + 1, text_pos.y - 1), black_outline, text);
                draw_list->AddText(ImVec2(text_pos.x - 1, text_pos.y    ), black_outline, text);
                draw_list->AddText(ImVec2(text_pos.x + 1, text_pos.y    ), black_outline, text);
                draw_list->AddText(ImVec2(text_pos.x - 1, text_pos.y + 1), black_outline, text);
                draw_list->AddText(ImVec2(text_pos.x,     text_pos.y + 1), black_outline, text);
                draw_list->AddText(ImVec2(text_pos.x + 1, text_pos.y + 1), black_outline, text);
                draw_list->AddText(text_pos, color, text);
                x_pos += CalcTextSize(text).x;
                };

            char buffer[32];

            draw_text_outlined("nebula.lua", text_x, text_color_u32);
         

            SetCursorPos(ImVec2(total_width, total_height));
        }
        gui->end();
        gui->pop_style_var(3);
    }
}

void c_gui::render_keybinds() {
    static float keybinds_window_alpha = 0.0f;
    keybinds_window_alpha =
        ImClamp(keybinds_window_alpha +
            gui->fixed_speed(8.0f) * (g_show_keybinds ? 1.0f : -1.0f),
            0.0f, 1.0f);

    if (keybinds_window_alpha > 0.01f) {
        const float anim_speed = gui->fixed_speed(8.f);
        for (auto& kb : g_keybind_registry) {
            if (kb.enabled_ptr && *kb.enabled_ptr && kb.key_ptr && *kb.key_ptr != 0) {
                bool should_show = false;

                if (kb.mode_ptr) {
                    if (*kb.mode_ptr == 0) {
                        should_show = (GetAsyncKeyState(*kb.key_ptr) & 0x8000) != 0;
                    }
                    else {
                        if (GetAsyncKeyState(*kb.key_ptr) & 0x1)
                            kb.toggle_state = !kb.toggle_state;
                        should_show = kb.toggle_state;
                    }
                }

                kb.alpha = ImClamp(kb.alpha + (anim_speed * (should_show ? 1.f : -1.f)), 0.f, 1.f);
            }
            else {
                kb.alpha = 0.0f;
                kb.toggle_state = false;
            }
        }

        static std::vector<KeybindInfo*> visible_keybinds;
        visible_keybinds.clear();

        for (auto& kb : g_keybind_registry) {
            if (kb.alpha > 0.01f)
                visible_keybinds.push_back(&kb);
        }

        gui->push_style_var(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        gui->push_style_var(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
        gui->push_style_var(ImGuiStyleVar_WindowBorderSize, 0.0f);

        gui->set_next_window_pos(ImVec2(20, 100), ImGuiCond_FirstUseEver);
        gui->begin("##keybinds", nullptr,
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_AlwaysAutoResize |
            ImGuiWindowFlags_NoScrollbar);
        {
            ImDrawList* draw_list = GetWindowDrawList();
            ImDrawList* bg_draw_list = GetBackgroundDrawList();
            ImVec2 pos = GetWindowPos();

            const float title_height = 23.0f;
            const float subheader_height = 20.0f;
            const float entry_height = 20.0f;
            const float footer_height = 8.0f + 20.0f; // separator gap + "Activity: Ready"
            const float min_width = 154.0f;
            const float padding_right = 5.0f;
            const float padding_left = 5.0f;

            if (CACHE.keybinds.keybind_count != visible_keybinds.size()) {
                CACHE.keybinds.max_name_width = 0.0f;
                CACHE.keybinds.max_mode_key_width = 0.0f;
                CACHE.keybinds.keybind_count = (int)visible_keybinds.size();

                extern const char* keys[];
                static char mode_key_buffer[64];

                {
                    const char* key_name = (var->gui.menu_key > 0 && var->gui.menu_key < 256)
                        ? keys[var->gui.menu_key] : "none";
                    snprintf(mode_key_buffer, sizeof(mode_key_buffer), "[%s]: Menu Bind", key_name);
                    float w = 10.0f + CACHE.text_size.get_or_calculate(std::string(mode_key_buffer)).x;
                    if (w > CACHE.keybinds.max_name_width)
                        CACHE.keybinds.max_name_width = w;
                }

                for (const auto* kb : visible_keybinds) {
                    const char* key_name = keys[*kb->key_ptr];
                    snprintf(mode_key_buffer, sizeof(mode_key_buffer), "[%s]: %s", key_name, kb->name.c_str());
                    float w = 10.0f + CACHE.text_size.get_or_calculate(std::string(mode_key_buffer)).x;
                    if (w > CACHE.keybinds.max_name_width)
                        CACHE.keybinds.max_name_width = w;
                }
            }

            float total_width = min_width;
            {
                float calculated_width = padding_left + CACHE.keybinds.max_name_width + padding_right;
                if (calculated_width > total_width)
                    total_width = calculated_width;
            }

            float entries_height = subheader_height; // "Keybinds" row
            entries_height += entry_height;           // menu bind (always shown)
            for (const auto* kb : visible_keybinds)
                entries_height += entry_height * kb->alpha;

            const float total_height = title_height + entries_height + footer_height;

            ImU32 stroke_color = CACHE.color.get_or_calculate(clr->window.stroke, keybinds_window_alpha);
            ImU32 gradient_color = CACHE.color.get_or_calculate(clr->window.gradient, keybinds_window_alpha);
            ImU32 bg_two_color = CACHE.color.get_or_calculate(clr->window.background_two, keybinds_window_alpha);
            ImU32 accent_color = CACHE.color.get_or_calculate(clr->accent, keybinds_window_alpha);
            ImU32 shadow_color = CACHE.color.get_or_calculate(ImVec4(0, 0, 0, 0.5f), keybinds_window_alpha);
            ImU32 text_color_base = CACHE.color.get_or_calculate(clr->widgets.text, keybinds_window_alpha);

            draw->rect(bg_draw_list, pos - ImVec2(1, 1),
                ImVec2(pos.x + total_width + 1, pos.y + total_height + 1),
                shadow_color);

            draw->rect_filled(draw_list, pos,
                ImVec2(pos.x + total_width, pos.y + total_height),
                stroke_color);

            draw->fade_rect_filled(
                draw_list, ImVec2(pos.x + 1, pos.y + 1),
                ImVec2(pos.x + total_width - 1, pos.y + total_height - 1),
                gradient_color, bg_two_color, fade_direction::vertically);

            draw->rect_filled(draw_list, ImVec2(pos.x + 1, pos.y + 1),
                ImVec2(pos.x + total_width - 1, pos.y + 3),
                accent_color);

            if (entries_height > 0.0f) {
                draw->rect_filled(
                    draw_list, ImVec2(pos.x + 1, pos.y + title_height),
                    ImVec2(pos.x + total_width - 1, pos.y + total_height - 1),
                    bg_two_color);
            }

            const float title_y =
                3.0f + ((title_height - 3.0f - CACHE.keybinds.title_text_height) * 0.5f);
            ImVec2 title_pos(pos.x + padding_left, pos.y + title_y);
            const ImU32 black_outline = IM_COL32(0, 0, 0, (int)(255 * keybinds_window_alpha));

            draw_list->AddText(ImVec2(title_pos.x - 1, title_pos.y - 1), black_outline, "Activity");
            draw_list->AddText(ImVec2(title_pos.x,     title_pos.y - 1), black_outline, "Activity");
            draw_list->AddText(ImVec2(title_pos.x + 1, title_pos.y - 1), black_outline, "Activity");
            draw_list->AddText(ImVec2(title_pos.x - 1, title_pos.y    ), black_outline, "Activity");
            draw_list->AddText(ImVec2(title_pos.x + 1, title_pos.y    ), black_outline, "Activity");
            draw_list->AddText(ImVec2(title_pos.x - 1, title_pos.y + 1), black_outline, "Activity");
            draw_list->AddText(ImVec2(title_pos.x,     title_pos.y + 1), black_outline, "Activity");
            draw_list->AddText(ImVec2(title_pos.x + 1, title_pos.y + 1), black_outline, "Activity");
            draw_list->AddText(title_pos, text_color_base, "Activity");

            float entry_y = title_height;
            extern const char* keys[];
            static char mode_key_buffer[64];

            auto draw_entry = [&](ImVec2 p, ImU32 col, ImU32 outline, const char* text) {
                draw_list->AddText(ImVec2(p.x - 1, p.y - 1), outline, text);
                draw_list->AddText(ImVec2(p.x,     p.y - 1), outline, text);
                draw_list->AddText(ImVec2(p.x + 1, p.y - 1), outline, text);
                draw_list->AddText(ImVec2(p.x - 1, p.y    ), outline, text);
                draw_list->AddText(ImVec2(p.x + 1, p.y    ), outline, text);
                draw_list->AddText(ImVec2(p.x - 1, p.y + 1), outline, text);
                draw_list->AddText(ImVec2(p.x,     p.y + 1), outline, text);
                draw_list->AddText(ImVec2(p.x + 1, p.y + 1), outline, text);
                draw_list->AddText(p, col, text);
            };

            {
                const float text_y_offset = (subheader_height - CACHE.keybinds.text_height) * 0.5f;
                ImVec2 p(pos.x + padding_left + 10.0f, pos.y + entry_y + text_y_offset);
                draw_entry(p, text_color_base, black_outline, "Keybinds");
                entry_y += subheader_height;
            }

            {
                const char* key_name = (var->gui.menu_key > 0 && var->gui.menu_key < 256)
                    ? keys[var->gui.menu_key] : "none";
                snprintf(mode_key_buffer, sizeof(mode_key_buffer), "[%s]: Menu Bind", key_name);
                const float text_y_offset = (entry_height - CACHE.keybinds.text_height) * 0.5f;
                ImVec2 p(pos.x + padding_left + 20.0f, pos.y + entry_y + text_y_offset);
                draw_entry(p, text_color_base, black_outline, mode_key_buffer);
                entry_y += entry_height;
            }

            for (const auto* kb : visible_keybinds) {
                const float current_entry_height = entry_height * kb->alpha;
                const int alpha_int = (int)(255 * kb->alpha * keybinds_window_alpha);
                const ImU32 text_color   = IM_COL32((int)(clr->widgets.text.Value.x * 255),
                                                    (int)(clr->widgets.text.Value.y * 255),
                                                    (int)(clr->widgets.text.Value.z * 255), alpha_int);
                const ImU32 outline_color = IM_COL32(0, 0, 0, alpha_int);

                const char* key_name = keys[*kb->key_ptr];
                snprintf(mode_key_buffer, sizeof(mode_key_buffer), "[%s]: %s", key_name, kb->name.c_str());

                const float text_y_offset = (entry_height - CACHE.keybinds.text_height) * 0.5f;
                ImVec2 p(pos.x + padding_left + 20.0f, pos.y + entry_y + text_y_offset);
                draw_entry(p, text_color, outline_color, mode_key_buffer);

                entry_y += current_entry_height;
            }

            const ImU32 sep_col = IM_COL32(255, 255, 255, (int)(60 * keybinds_window_alpha));
            draw_list->AddLine(ImVec2(pos.x + padding_left, pos.y + entry_y + 3),
                ImVec2(pos.x + total_width - padding_right, pos.y + entry_y + 3), sep_col, 1.f);
            entry_y += 8.0f;

            {
                const float text_y_offset = (entry_height - CACHE.keybinds.text_height) * 0.5f;
                ImVec2 p(pos.x + padding_left, pos.y + entry_y + text_y_offset);
                draw_entry(p, text_color_base, black_outline, "Activity: Ready");
            }

            SetCursorPos(ImVec2(total_width, total_height));
        }
        gui->end();
        gui->pop_style_var(3);
    }
}
